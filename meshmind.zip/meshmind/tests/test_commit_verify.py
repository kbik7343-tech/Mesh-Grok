import random
import unittest

from meshmind.verification.commit_verify import (
    SpotCheckVerifier, commit, verify_commitment,
)


class TestCommitReveal(unittest.TestCase):
    def test_valid_reveal_verifies(self):
        data = b"honest computation result"
        nonce = b"random_nonce_123"
        committed = commit(data, nonce)
        self.assertTrue(verify_commitment(data, nonce, committed))

    def test_tampered_data_fails_verification(self):
        data = b"honest result"
        nonce = b"nonce"
        committed = commit(data, nonce)
        self.assertFalse(verify_commitment(b"tampered result", nonce, committed))

    def test_cannot_change_answer_after_seeing_others(self):
        """
        Ключевое свойство commit-reveal: узел публикует хэш ДО того,
        как видит правильный ответ. Если бы он знал ответ заранее и
        попытался его "подставить" после факта — хэш обязательства,
        вычисленный с другим nonce, не совпадёт.
        """
        honest_data = b"real_computation_42"
        honest_nonce = b"nonce_a"
        committed_hash = commit(honest_data, honest_nonce)  # опубликовано ДО

        # Узел видит "правильный" ответ от кого-то другого и хочет его подставить
        leaked_correct_answer = b"leaked_correct_answer"
        fake_nonce = b"nonce_b"
        self.assertFalse(
            verify_commitment(leaked_correct_answer, fake_nonce, committed_hash),
            "Подмена результата после публикации обязательства должна проваливать проверку",
        )


class TestSpotCheckVerifier(unittest.TestCase):
    def test_honest_node_passes_spot_check(self):
        verifier = SpotCheckVerifier()
        data = b"input"
        output = b"correct_output"
        nonce = b"nonce1"

        verifier.record_commitment("req1", "nodeA", data, output, nonce)
        result = verifier.spot_check("req1", trusted_recomputation=b"correct_output")
        self.assertTrue(result)
        self.assertEqual(verifier.cheating_count("nodeA"), 0)

    def test_dishonest_node_caught_by_spot_check(self):
        verifier = SpotCheckVerifier()
        data = b"input"
        fake_output = b"made_up_wrong_answer"  # узел не считал честно, выдумал
        nonce = b"nonce1"

        verifier.record_commitment("req1", "cheaterNode", data, fake_output, nonce)
        result = verifier.spot_check("req1", trusted_recomputation=b"actual_correct_answer")

        self.assertFalse(result)
        self.assertEqual(verifier.cheating_count("cheaterNode"), 1)

    def test_node_flagged_after_threshold_violations(self):
        verifier = SpotCheckVerifier()
        for i in range(3):
            verifier.record_commitment(f"req{i}", "repeatOffender", b"in", b"wrong", b"n")
            verifier.spot_check(f"req{i}", trusted_recomputation=b"correct")

        self.assertTrue(verifier.is_flagged("repeatOffender", threshold=2))

    def test_honest_node_never_flagged(self):
        verifier = SpotCheckVerifier()
        for i in range(10):
            verifier.record_commitment(f"req{i}", "goodNode", b"in", b"same_answer", b"n")
            verifier.spot_check(f"req{i}", trusted_recomputation=b"same_answer")
        self.assertFalse(verifier.is_flagged("goodNode"))

    def test_spot_check_probability_distribution(self):
        """
        Проверяем статистическое свойство: при probability=0.1 доля
        реально выбранных на проверку запросов из большой выборки
        должна быть близка к 10%, а не произвольной.
        """
        verifier = SpotCheckVerifier(check_probability=0.1, rng=random.Random(42))
        checked = sum(1 for _ in range(5000) if verifier.should_spot_check())
        fraction = checked / 5000
        self.assertAlmostEqual(fraction, 0.1, delta=0.02)

    def test_missing_record_raises(self):
        verifier = SpotCheckVerifier()
        with self.assertRaises(ValueError):
            verifier.spot_check("nonexistent_request", trusted_recomputation=b"x")

    def test_detection_probability_grows_with_repeated_checks(self):
        """
        Демонстрация заявленного в докстринге свойства: вероятность
        поимки нечестного узла растёт с числом перепроверок. Здесь
        симулируем узла, который обманывает каждый раз, и считаем,
        после скольких ПРОВЕРЕННЫХ запросов он будет пойман хотя бы раз
        статистически почти всегда (детерминированно в данном случае,
        т.к. spot_check здесь вызывается явно, а не вероятностно).
        """
        verifier = SpotCheckVerifier()
        caught_at = None
        for i in range(20):
            verifier.record_commitment(f"req{i}", "sneaky", b"in", b"always_wrong", b"n")
            honest = verifier.spot_check(f"req{i}", trusted_recomputation=b"always_right")
            if not honest and caught_at is None:
                caught_at = i
        self.assertEqual(caught_at, 0, "Нечестный узел должен был быть пойман на первой же проверке")


if __name__ == "__main__":
    unittest.main()
