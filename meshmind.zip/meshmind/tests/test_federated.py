import unittest

from meshmind.hybrid.federated import (
    ClientUpdate, apply_update, federated_average, filter_outlier_updates,
)


class TestFederatedAverage(unittest.TestCase):
    def test_equal_weight_simple_average(self):
        updates = [
            ClientUpdate("n1", [1.0, 2.0], num_local_samples=100),
            ClientUpdate("n2", [3.0, 4.0], num_local_samples=100),
        ]
        result = federated_average(updates)
        self.assertAlmostEqual(result[0], 2.0)  # (1+3)/2
        self.assertAlmostEqual(result[1], 3.0)  # (2+4)/2

    def test_weighted_by_sample_size(self):
        """
        Узел с 900 примерами должен влиять в 9 раз сильнее узла со 100 —
        это ключевое свойство FedAvg, отличающее его от наивного среднего.
        """
        updates = [
            ClientUpdate("big", [10.0], num_local_samples=900),
            ClientUpdate("small", [0.0], num_local_samples=100),
        ]
        result = federated_average(updates)
        # Взвешенное среднее: 10*0.9 + 0*0.1 = 9.0, а не наивное (10+0)/2=5.0
        self.assertAlmostEqual(result[0], 9.0)

    def test_single_update_returns_itself(self):
        updates = [ClientUpdate("n1", [5.0, -2.0], num_local_samples=50)]
        result = federated_average(updates)
        self.assertEqual(result, [5.0, -2.0])

    def test_empty_updates_raises(self):
        with self.assertRaises(ValueError):
            federated_average([])

    def test_mismatched_dimensions_raise(self):
        updates = [
            ClientUpdate("n1", [1.0, 2.0], num_local_samples=10),
            ClientUpdate("n2", [1.0, 2.0, 3.0], num_local_samples=10),  # другая размерность
        ]
        with self.assertRaises(ValueError):
            federated_average(updates)

    def test_zero_total_samples_raises(self):
        updates = [ClientUpdate("n1", [1.0], num_local_samples=0)]
        with self.assertRaises(ValueError):
            federated_average(updates)


class TestApplyUpdate(unittest.TestCase):
    def test_apply_with_default_learning_rate(self):
        result = apply_update([1.0, 2.0], [0.5, -0.5])
        self.assertEqual(result, [1.5, 1.5])

    def test_apply_with_scaled_learning_rate(self):
        result = apply_update([1.0, 1.0], [1.0, 1.0], learning_rate=0.1)
        self.assertAlmostEqual(result[0], 1.1)
        self.assertAlmostEqual(result[1], 1.1)

    def test_dimension_mismatch_raises(self):
        with self.assertRaises(ValueError):
            apply_update([1.0, 2.0], [1.0])


class TestFilterOutlierUpdates(unittest.TestCase):
    def test_honest_updates_all_kept(self):
        updates = [
            ClientUpdate("n1", [0.1, 0.1], num_local_samples=10),
            ClientUpdate("n2", [0.2, -0.1], num_local_samples=10),
        ]
        kept, rejected = filter_outlier_updates(updates, max_delta_norm=1.0)
        self.assertEqual(len(kept), 2)
        self.assertEqual(rejected, [])

    def test_poisoning_attack_update_rejected(self):
        """
        Атакующий узел присылает аномально большое обновление, пытаясь
        сильно сместить модель в свою пользу за один раунд.
        """
        updates = [
            ClientUpdate("honest", [0.1, 0.1], num_local_samples=10),
            ClientUpdate("attacker", [500.0, -500.0], num_local_samples=10),  # атака
        ]
        kept, rejected = filter_outlier_updates(updates, max_delta_norm=5.0)
        self.assertEqual([u.node_id for u in kept], ["honest"])
        self.assertEqual(rejected, ["attacker"])

    def test_norm_boundary_is_inclusive(self):
        # Вектор [3.0, 4.0] имеет норму ровно 5.0 (классический 3-4-5 треугольник)
        updates = [ClientUpdate("n1", [3.0, 4.0], num_local_samples=10)]
        kept, rejected = filter_outlier_updates(updates, max_delta_norm=5.0)
        self.assertEqual(len(kept), 1, "Норма ровно на границе должна приниматься (<=), не отклоняться")


class TestFullFederatedRound(unittest.TestCase):
    """Интеграционный сценарий: фильтрация -> усреднение -> применение к глобальным весам."""

    def test_end_to_end_round_with_poisoning_defense(self):
        global_weights = [1.0, 1.0]
        updates = [
            ClientUpdate("n1", [0.1, 0.0], num_local_samples=200),
            ClientUpdate("n2", [0.0, 0.1], num_local_samples=200),
            ClientUpdate("attacker", [100.0, 100.0], num_local_samples=1),  # пытается доминировать
        ]

        kept, rejected = filter_outlier_updates(updates, max_delta_norm=1.0)
        self.assertEqual(rejected, ["attacker"])

        avg_delta = federated_average(kept)
        new_weights = apply_update(global_weights, avg_delta)

        # Без защиты атакующий сместил бы веса на сотни; с защитой — изменение небольшое
        self.assertLess(abs(new_weights[0] - 1.0), 1.0)
        self.assertLess(abs(new_weights[1] - 1.0), 1.0)


if __name__ == "__main__":
    unittest.main()
