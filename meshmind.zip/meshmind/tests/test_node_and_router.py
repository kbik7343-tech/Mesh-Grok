import unittest

from meshmind.node import NodeCapabilities, NodeInfo
from meshmind.router import NodeHealth, RoutingTable


class TestNodeCapabilities(unittest.TestCase):
    def test_capacity_score_scales_with_ram(self):
        low_ram = NodeCapabilities(ram_gb=4.0, has_gpu=False, gpu_name="none", os_name="Linux", cpu_arch="x86_64")
        high_ram = NodeCapabilities(ram_gb=32.0, has_gpu=False, gpu_name="none", os_name="Linux", cpu_arch="x86_64")
        self.assertLess(low_ram.estimated_capacity_score(), high_ram.estimated_capacity_score())

    def test_gpu_multiplies_capacity(self):
        no_gpu = NodeCapabilities(ram_gb=16.0, has_gpu=False, gpu_name="none", os_name="Linux", cpu_arch="x86_64")
        with_gpu = NodeCapabilities(ram_gb=16.0, has_gpu=True, gpu_name="RTX 4090", os_name="Linux", cpu_arch="x86_64")
        self.assertEqual(with_gpu.estimated_capacity_score(), no_gpu.estimated_capacity_score() * 3.0)

    def test_zero_ram_does_not_crash(self):
        caps = NodeCapabilities(ram_gb=0.0, has_gpu=False, gpu_name="none", os_name="Linux", cpu_arch="x86_64")
        self.assertGreater(caps.estimated_capacity_score(), 0)  # минимум 0.1, не 0 и не отрицательное


class TestNodeInfo(unittest.TestCase):
    def test_unique_ids_generated(self):
        a, b = NodeInfo(), NodeInfo()
        self.assertNotEqual(a.node_id, b.node_id)

    def test_summary_contains_key_fields(self):
        info = NodeInfo()
        summary = info.summary()
        self.assertIn(info.node_id, summary)
        self.assertIn("RAM", summary)


class TestNodeHealth(unittest.TestCase):
    def test_success_improves_score(self):
        health = NodeHealth(node_id="n1")
        score_before = health.routing_score()
        health.record_success(latency_ms=10.0)
        self.assertLess(health.routing_score(), score_before)

    def test_failure_worsens_score(self):
        health = NodeHealth(node_id="n1")
        score_before = health.routing_score()
        health.record_failure()
        self.assertGreater(health.routing_score(), score_before)

    def test_repeated_failures_push_success_rate_toward_zero(self):
        health = NodeHealth(node_id="n1")
        for _ in range(20):
            health.record_failure()
        self.assertLess(health.success_rate, 0.01)

    def test_stale_detection(self):
        health = NodeHealth(node_id="n1")
        self.assertFalse(health.is_stale(timeout_s=60.0))
        health.last_seen -= 100  # имитируем "100 секунд назад"
        self.assertTrue(health.is_stale(timeout_s=60.0))


class TestRoutingTable(unittest.TestCase):
    def setUp(self):
        self.rt = RoutingTable()
        self.rt.register_block_owner(0, "nodeA")
        self.rt.register_block_owner(0, "nodeB")
        self.rt.register_block_owner(1, "nodeC")

    def test_build_route_picks_best_owner_per_block(self):
        self.rt.report_result("nodeA", ok=True, latency_ms=10)
        self.rt.report_result("nodeB", ok=True, latency_ms=500)
        route = self.rt.build_route(num_blocks=2)
        self.assertEqual(route[0], "nodeA")  # быстрее nodeB
        self.assertEqual(route[1], "nodeC")  # единственный владелец блока 1

    def test_missing_block_raises(self):
        with self.assertRaises(RuntimeError):
            self.rt.build_route(num_blocks=5)  # блоков 2,3,4 нет ни у кого

    def test_unreliable_node_loses_to_slower_reliable_node(self):
        # Узел с идеальным пингом, но частыми сбоями, должен проиграть
        # чуть более медленному, но надёжному — ключевое свойство router.py
        self.rt.report_result("nodeA", ok=True, latency_ms=5)  # очень быстрый
        for _ in range(10):
            self.rt.report_result("nodeA", ok=False)  # но постоянно падает
        self.rt.report_result("nodeB", ok=True, latency_ms=200)  # медленнее, но стабилен
        for _ in range(10):
            self.rt.report_result("nodeB", ok=True, latency_ms=200)

        route = self.rt.build_route(num_blocks=1)
        self.assertEqual(route[0], "nodeB", "Надёжный узел должен победить быстрый, но нестабильный")

    def test_load_balancing_via_active_requests(self):
        route1 = self.rt.build_route(num_blocks=1)  # занимает nodeA или nodeB
        occupied_node = route1[0]
        # Пока маршрут 1 "активен" (не release), повторный build_route
        # должен учитывать возросшую нагрузку занятого узла
        health_before = self.rt._health[occupied_node].active_requests
        self.assertEqual(health_before, 1)
        self.rt.release_route(route1)
        self.assertEqual(self.rt._health[occupied_node].active_requests, 0)


if __name__ == "__main__":
    unittest.main()
