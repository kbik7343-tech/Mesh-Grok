import unittest

from meshmind.transport.gossip import GossipNode


class TestGossipProtocol(unittest.IsolatedAsyncioTestCase):
    """
    Реальная сеть: каждый GossipNode — настоящий TCP-сервер/клиент.
    Проверяем, что знание о составе сети распространяется через обмен
    сообщениями, а не передаётся напрямую в памяти (как было бы с моками).
    """

    async def test_two_nodes_discover_each_other_via_bootstrap(self):
        nodeA = GossipNode(node_id="A")
        nodeB = GossipNode(node_id="B")
        portA = await nodeA.start()
        portB = await nodeB.start()
        try:
            # B узнаёт о A через единственный bootstrap-запрос
            await nodeB.bootstrap("127.0.0.1", portA)

            self.assertIn("A", nodeB.known_peers)
            # И A, получив запрос от B, тоже должен был узнать о B
            self.assertIn("B", nodeA.known_peers)
        finally:
            await nodeA.stop()
            await nodeB.stop()

    async def test_transitive_discovery_through_gossip_rounds(self):
        """
        A и B не знают друг о друге напрямую. C знает обоих. После
        нескольких раундов gossip A должен узнать о B ЧЕРЕЗ C — это и
        есть самоорганизация топологии, ключевое свойство gossip.
        """
        nodeA = GossipNode(node_id="A", fanout=2)
        nodeB = GossipNode(node_id="B", fanout=2)
        nodeC = GossipNode(node_id="C", fanout=2)

        portA = await nodeA.start()
        portB = await nodeB.start()
        portC = await nodeC.start()

        try:
            # C знает про A и B напрямую (имитируем, что C был посредником при старте)
            await nodeC.bootstrap("127.0.0.1", portA)
            await nodeC.bootstrap("127.0.0.1", portB)
            self.assertIn("A", nodeC.known_peers)
            self.assertIn("B", nodeC.known_peers)

            # A пока знает только C (через bootstrap выше A->C уже тоже узнал про C)
            self.assertIn("C", nodeA.known_peers)
            self.assertNotIn("B", nodeA.known_peers, "На этом этапе A ещё не должен знать о B")

            # Раунд gossip: A связывается с известными пирами (пока только C)
            await nodeA.gossip_round()

            # Теперь A должен был узнать о B транзитивно через C
            self.assertIn("B", nodeA.known_peers, "A должен был узнать о B через gossip с C")
        finally:
            await nodeA.stop()
            await nodeB.stop()
            await nodeC.stop()

    async def test_unreachable_peer_does_not_crash_gossip_round(self):
        nodeA = GossipNode(node_id="A", fanout=1)
        await nodeA.start()
        try:
            # Добавляем заведомо недоступный "призрачный" узел
            from meshmind.transport.gossip import PeerRecord
            nodeA.known_peers["ghost"] = PeerRecord(node_id="ghost", host="127.0.0.1", port=1)

            successes = await nodeA.gossip_round()
            self.assertEqual(successes, 0, "Недоступный узел не должен давать успешный обмен")
            # И главное — не должно быть необработанного исключения (тест сам по себе это проверяет)
        finally:
            await nodeA.stop()

    async def test_prune_removes_stale_peers(self):
        import time
        from meshmind.transport.gossip import PeerRecord

        node = GossipNode(node_id="A", staleness_timeout_s=0.05)
        node.known_peers["old"] = PeerRecord(node_id="old", host="127.0.0.1", port=1234)
        node.known_peers["old"].last_heard_from = time.time() - 10  # давно не слышно

        removed = node.prune_stale_peers()
        self.assertEqual(removed, 1)
        self.assertNotIn("old", node.known_peers)

    async def test_fresher_info_overrides_stale_info_on_merge(self):
        node = GossipNode(node_id="A")
        # Устаревшая информация о узле B (другой порт)
        node._merge_peer_list([{"node_id": "B", "host": "127.0.0.1", "port": 1111, "last_heard_from": 100.0}])
        # Более свежая информация о том же узле B (сменил порт после перезапуска)
        node._merge_peer_list([{"node_id": "B", "host": "127.0.0.1", "port": 2222, "last_heard_from": 200.0}])

        self.assertEqual(node.known_peers["B"].port, 2222, "Должна победить более свежая запись")

    async def test_does_not_add_self_to_known_peers(self):
        nodeA = GossipNode(node_id="A")
        await nodeA.start()
        try:
            nodeA._merge_peer_list([{"node_id": "A", "host": "x", "port": 1, "last_heard_from": time_now()}])
            self.assertNotIn("A", nodeA.known_peers)
        finally:
            await nodeA.stop()


def time_now() -> float:
    import time
    return time.time()


if __name__ == "__main__":
    unittest.main()
