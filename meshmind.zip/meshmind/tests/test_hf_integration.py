import unittest

from meshmind.hf_integration import _load_shard_weights


class FakeBlock:
    def __init__(self):
        self.received_state = None

    def load_state_dict(self, state_dict, strict=False):
        self.received_state = state_dict
        return [], []


class TestLoadShardWeights(unittest.TestCase):
    """
    Самая рискованная часть hf_integration.py — ошибка здесь тихо
    смешала бы веса разных блоков модели. Тестируем без реального
    torch через лёгкую заглушку, реализующую только load_state_dict.
    """

    def test_prefix_stripping_routes_weights_correctly(self):
        blocks = [FakeBlock(), FakeBlock(), FakeBlock()]
        state_dict = {
            "block_0.attn.weight": "W0_attn",
            "block_0.mlp.weight": "W0_mlp",
            "block_1.attn.weight": "W1_attn",
            "block_2.attn.weight": "W2_attn",
        }
        _load_shard_weights(blocks, state_dict)

        self.assertEqual(blocks[0].received_state, {"attn.weight": "W0_attn", "mlp.weight": "W0_mlp"})
        self.assertEqual(blocks[1].received_state, {"attn.weight": "W1_attn"})
        self.assertEqual(blocks[2].received_state, {"attn.weight": "W2_attn"})

    def test_missing_block_weights_raises(self):
        with self.assertRaises(ValueError):
            _load_shard_weights([FakeBlock(), FakeBlock()], {"block_0.w": "x"})

    def test_no_cross_block_contamination(self):
        """Веса одного блока не должны просочиться в другой при схожих именах параметров."""
        blocks = [FakeBlock(), FakeBlock()]
        state_dict = {
            "block_0.shared_name.weight": "from_block_0",
            "block_1.shared_name.weight": "from_block_1",
        }
        _load_shard_weights(blocks, state_dict)
        self.assertEqual(blocks[0].received_state["shared_name.weight"], "from_block_0")
        self.assertEqual(blocks[1].received_state["shared_name.weight"], "from_block_1")


if __name__ == "__main__":
    unittest.main()
