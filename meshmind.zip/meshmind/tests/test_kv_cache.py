import time
import unittest

from meshmind.transport.kv_cache import SessionKVCache


class TestSessionKVCache(unittest.TestCase):
    def test_put_then_get_roundtrip(self):
        cache = SessionKVCache()
        cache.put("session1", 0, 5, b"kv_data_123")
        self.assertEqual(cache.get("session1", 0, 5), b"kv_data_123")

    def test_miss_returns_none(self):
        cache = SessionKVCache()
        self.assertIsNone(cache.get("unknown_session", 0, 5))

    def test_different_block_ranges_are_separate_entries(self):
        cache = SessionKVCache()
        cache.put("session1", 0, 5, b"blocks_0_5")
        cache.put("session1", 5, 10, b"blocks_5_10")
        self.assertEqual(cache.get("session1", 0, 5), b"blocks_0_5")
        self.assertEqual(cache.get("session1", 5, 10), b"blocks_5_10")

    def test_different_sessions_do_not_collide(self):
        cache = SessionKVCache()
        cache.put("session1", 0, 5, b"data_for_1")
        cache.put("session2", 0, 5, b"data_for_2")
        self.assertEqual(cache.get("session1", 0, 5), b"data_for_1")
        self.assertEqual(cache.get("session2", 0, 5), b"data_for_2")

    def test_ttl_expiry(self):
        cache = SessionKVCache(ttl_seconds=0.05)
        cache.put("session1", 0, 5, b"data")
        self.assertIsNotNone(cache.get("session1", 0, 5))
        time.sleep(0.1)
        self.assertIsNone(cache.get("session1", 0, 5), "Запись должна была истечь по TTL")

    def test_touch_on_get_resets_ttl_clock(self):
        cache = SessionKVCache(ttl_seconds=0.15)
        cache.put("session1", 0, 5, b"data")
        time.sleep(0.08)
        cache.get("session1", 0, 5)  # touch — обновляет last_used_at
        time.sleep(0.08)
        # Прошло 0.16с с put, но только 0.08с с последнего get — должно быть ещё живо
        self.assertIsNotNone(cache.get("session1", 0, 5))

    def test_invalidate_session_removes_only_that_session(self):
        cache = SessionKVCache()
        cache.put("session1", 0, 5, b"data1")
        cache.put("session2", 0, 5, b"data2")
        removed = cache.invalidate_session("session1")
        self.assertEqual(removed, 1)
        self.assertIsNone(cache.get("session1", 0, 5))
        self.assertIsNotNone(cache.get("session2", 0, 5))

    def test_capacity_eviction_removes_lru_first(self):
        # Лимит в 30 байт — хватит на 2 записи по 10 байт, третья вытеснит самую старую
        cache = SessionKVCache(max_total_bytes=25)
        cache.put("s1", 0, 1, b"a" * 10)
        time.sleep(0.01)
        cache.put("s2", 0, 1, b"b" * 10)
        time.sleep(0.01)
        cache.get("s1", 0, 1)  # "трогаем" s1 — теперь s2 самый давний по использованию
        time.sleep(0.01)
        cache.put("s3", 0, 1, b"c" * 10)  # должно вытеснить s2, а не s1

        self.assertIsNone(cache.get("s2", 0, 1), "s2 должен был быть вытеснен как наименее используемый")
        self.assertIsNotNone(cache.get("s1", 0, 1), "s1 трогали недавно, должен остаться")
        self.assertIsNotNone(cache.get("s3", 0, 1))

    def test_stats_reports_correct_counts(self):
        cache = SessionKVCache()
        cache.put("s1", 0, 5, b"x" * 100)
        cache.put("s1", 5, 10, b"y" * 50)
        cache.put("s2", 0, 5, b"z" * 20)

        stats = cache.stats()
        self.assertEqual(stats["entries"], 3)
        self.assertEqual(stats["total_bytes"], 170)
        self.assertEqual(stats["sessions"], 2)


if __name__ == "__main__":
    unittest.main()
