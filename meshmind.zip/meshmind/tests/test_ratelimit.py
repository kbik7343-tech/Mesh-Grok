import time
import unittest

from meshmind.ratelimit import RateLimiter, TokenBucket
from meshmind.transport.asyncio_transport import MeshClient, NodeServer
from meshmind.router import RoutingTable


class TestTokenBucket(unittest.TestCase):
    def test_starts_full_and_allows_burst(self):
        bucket = TokenBucket(capacity=5, refill_rate=1)
        for _ in range(5):
            self.assertTrue(bucket.try_consume())
        self.assertFalse(bucket.try_consume(), "6-й запрос подряд должен быть отклонён")

    def test_refills_over_time(self):
        bucket = TokenBucket(capacity=2, refill_rate=10)  # 10 токенов/сек — быстро для теста
        bucket.try_consume()
        bucket.try_consume()
        self.assertFalse(bucket.try_consume())
        time.sleep(0.15)  # за 0.15с должно накопиться ~1.5 токена
        self.assertTrue(bucket.try_consume())

    def test_never_exceeds_capacity(self):
        bucket = TokenBucket(capacity=3, refill_rate=100)
        time.sleep(0.1)  # много времени на восполнение
        bucket._refill()
        self.assertLessEqual(bucket._tokens, 3)

    def test_time_until_available(self):
        bucket = TokenBucket(capacity=1, refill_rate=2)  # 2 токена/сек
        bucket.try_consume()  # опустошили
        wait = bucket.time_until_available()
        self.assertAlmostEqual(wait, 0.5, delta=0.05)  # нужно 0.5с на 1 токен при скорости 2/с


class TestRateLimiter(unittest.TestCase):
    def test_different_clients_have_independent_buckets(self):
        limiter = RateLimiter(capacity=2, refill_rate=1)
        self.assertTrue(limiter.allow("clientA"))
        self.assertTrue(limiter.allow("clientA"))
        self.assertFalse(limiter.allow("clientA"))  # clientA исчерпал лимит

        self.assertTrue(limiter.allow("clientB"))  # clientB не затронут лимитом clientA

    def test_reset_restores_capacity(self):
        limiter = RateLimiter(capacity=1, refill_rate=0.001)  # почти не восполняется сам
        self.assertTrue(limiter.allow("clientA"))
        self.assertFalse(limiter.allow("clientA"))
        limiter.reset("clientA")
        self.assertTrue(limiter.allow("clientA"), "После reset лимит должен быть снят")

    def test_active_clients_count(self):
        limiter = RateLimiter()
        limiter.allow("a")
        limiter.allow("b")
        limiter.allow("a")  # повторный запрос того же клиента не создаёт новое ведро
        self.assertEqual(limiter.active_clients(), 2)


class TestRateLimitIntegrationWithRealServer(unittest.IsolatedAsyncioTestCase):
    """Проверяет rate limiting не изолированно, а через настоящий TCP-сервер."""

    async def test_server_rejects_requests_over_limit(self):
        limiter = RateLimiter(capacity=2, refill_rate=0.001)  # 2 запроса, почти без восполнения
        server = NodeServer(
            node_id="n1",
            block_runner=lambda p, s, e: p,
            rate_limiter=limiter,
        )
        port = await server.start()
        try:
            router = RoutingTable()
            router.register_block_owner(0, "n1")
            client = MeshClient({"n1": ("127.0.0.1", port)}, router)

            # Первые 2 запроса должны пройти (емкость ведра = 2)
            await client.run_inference(b"first", num_blocks=1)
            await client.run_inference(b"second", num_blocks=1)

            # Третий должен быть отклонён лимитером на сервере
            with self.assertRaises(RuntimeError) as ctx:
                await client.run_inference(b"third", num_blocks=1)
            self.assertIn("rate_limited", str(ctx.exception))
        finally:
            await server.stop()

    async def test_server_without_limiter_has_no_restriction(self):
        server = NodeServer(node_id="n1", block_runner=lambda p, s, e: p, rate_limiter=None)
        port = await server.start()
        try:
            router = RoutingTable()
            router.register_block_owner(0, "n1")
            client = MeshClient({"n1": ("127.0.0.1", port)}, router)

            for _ in range(10):  # много запросов подряд — без лимитера все должны пройти
                result = await client.run_inference(b"x", num_blocks=1)
                self.assertEqual(result, b"x")
        finally:
            await server.stop()


if __name__ == "__main__":
    unittest.main()
