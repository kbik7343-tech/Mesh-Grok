import unittest
import urllib.request

from meshmind.service import MeshService, ServiceConfig
from meshmind.transport.asyncio_transport import MeshClient


class TestMeshService(unittest.IsolatedAsyncioTestCase):
    async def test_single_service_starts_and_reports_status(self):
        service = MeshService(ServiceConfig(dashboard_port=0))
        await service.start()
        try:
            status = service.status()
            self.assertEqual(status["node_id"], service.info.node_id)
            self.assertGreater(status["transport_port"], 0)
            self.assertGreater(status["gossip_port"], 0)
            self.assertIsNotNone(status["dashboard_url"])
        finally:
            await service.stop()

    async def test_dashboard_is_really_reachable_over_http(self):
        service = MeshService(ServiceConfig(dashboard_port=0))
        await service.start()
        try:
            with urllib.request.urlopen(service.dashboard_url + "/") as resp:
                self.assertEqual(resp.status, 200)
                body = resp.read().decode("utf-8")
                self.assertIn("meshmind", body)
        finally:
            await service.stop()

    async def test_two_services_discover_each_other_via_gossip(self):
        serviceA = MeshService(ServiceConfig(dashboard_port=None))
        serviceB = MeshService(ServiceConfig(dashboard_port=None))
        await serviceA.start()
        await serviceB.start()
        try:
            await serviceB.join_network(serviceA.config.host, serviceA.gossip_port)

            self.assertIn(serviceA.info.node_id, serviceB.gossip.known_peers)
            self.assertIn(serviceB.info.node_id, serviceA.gossip.known_peers)
        finally:
            await serviceA.stop()
            await serviceB.stop()

    async def test_real_request_through_transport_updates_router_and_incentives(self):
        """
        Полная цепочка: клиент -> реальный TCP-запрос к сервису ->
        block_runner обрабатывает -> router получает метрики ->
        incentives можно начислить на основе этого.
        """
        service = MeshService(ServiceConfig(dashboard_port=None))
        await service.start()
        try:
            router = RoutingTable_for_client()
            router.register_block_owner(0, service.info.node_id)
            client = MeshClient(
                {service.info.node_id: (service.config.host, service.transport_port)}, router
            )

            result = await client.run_inference(b"test_payload", num_blocks=1)
            self.assertEqual(result, b"test_payload|" + service.info.node_id.encode())

            status = service.status()
            self.assertEqual(status["requests_served"], 1)

            # Верификация тоже должна была сработать — проверяем, что commitment записан
            verifier = service.verifier
            self.assertEqual(len(verifier._records), 1)
        finally:
            await service.stop()

    async def test_rate_limiting_active_through_full_service(self):
        """Rate limiter встроен в сервис, а не просто существует отдельно — проверяем сквозь полный стек."""
        service = MeshService(ServiceConfig(
            dashboard_port=None, rate_limit_capacity=2, rate_limit_refill=0.001,
        ))
        await service.start()
        try:
            router = RoutingTable_for_client()
            router.register_block_owner(0, service.info.node_id)
            client = MeshClient(
                {service.info.node_id: (service.config.host, service.transport_port)}, router
            )

            await client.run_inference(b"1", num_blocks=1)
            await client.run_inference(b"2", num_blocks=1)
            with self.assertRaises(RuntimeError) as ctx:
                await client.run_inference(b"3", num_blocks=1)
            self.assertIn("rate_limited", str(ctx.exception))
        finally:
            await service.stop()


def RoutingTable_for_client():
    from meshmind.router import RoutingTable
    return RoutingTable()


if __name__ == "__main__":
    unittest.main()
