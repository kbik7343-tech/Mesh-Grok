import unittest

from meshmind.router import RoutingTable
from meshmind.transport.asyncio_transport import MeshClient, NodeServer


class TestAsyncioTransport(unittest.IsolatedAsyncioTestCase):
    """
    В отличие от остальных тестов, здесь поднимаются настоящие
    TCP-серверы на localhost — это не моки, а реальный сетевой
    round-trip, как и в ручной проверке из предыдущего ответа.
    """

    async def test_single_hop_roundtrip(self):
        server = NodeServer(node_id="n1", block_runner=lambda p, s, e: p + b"|processed")
        port = await server.start()
        try:
            router = RoutingTable()
            router.register_block_owner(0, "n1")
            client = MeshClient({"n1": ("127.0.0.1", port)}, router)

            result = await client.run_inference(b"input", num_blocks=1)
            self.assertEqual(result, b"input|processed")
        finally:
            await server.stop()

    async def test_three_hop_chain_preserves_order(self):
        servers = []
        addresses = {}
        router = RoutingTable()

        for i, name in enumerate(["nodeA", "nodeB", "nodeC"]):
            def make_runner(tag):
                return lambda p, s, e: p + f"|{tag}".encode()

            server = NodeServer(node_id=name, block_runner=make_runner(name))
            port = await server.start()
            servers.append(server)
            addresses[name] = ("127.0.0.1", port)
            router.register_block_owner(i, name)

        try:
            client = MeshClient(addresses, router)
            result = await client.run_inference(b"X", num_blocks=3)
            self.assertEqual(result, b"X|nodeA|nodeB|nodeC")
        finally:
            for server in servers:
                await server.stop()

    async def test_failed_node_raises_and_releases_route(self):
        def failing_runner(payload, start, end):
            raise ValueError("симуляция сбоя узла")

        server = NodeServer(node_id="broken", block_runner=failing_runner)
        port = await server.start()
        try:
            router = RoutingTable()
            router.register_block_owner(0, "broken")
            client = MeshClient({"broken": ("127.0.0.1", port)}, router)

            with self.assertRaises(RuntimeError):
                await client.run_inference(b"input", num_blocks=1)

            # Маршрут должен быть освобождён даже при ошибке (нагрузка не "зависает")
            self.assertEqual(router._health["broken"].active_requests, 0)
        finally:
            await server.stop()

    async def test_router_receives_real_network_latency_stats(self):
        server = NodeServer(node_id="n1", block_runner=lambda p, s, e: p)
        port = await server.start()
        try:
            router = RoutingTable()
            router.register_block_owner(0, "n1")
            client = MeshClient({"n1": ("127.0.0.1", port)}, router)

            await client.run_inference(b"test", num_blocks=1)
            health = router._health["n1"]
            self.assertGreater(health.ewma_latency_ms, 0)
            self.assertEqual(health.success_rate, 1.0)
        finally:
            await server.stop()


if __name__ == "__main__":
    unittest.main()
