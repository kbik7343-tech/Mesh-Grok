import json
import unittest
import urllib.request

from meshmind.dashboard.server import DashboardServer, build_stats_snapshot
from meshmind.incentives import IncentiveLedger
from meshmind.router import RoutingTable


class TestBuildStatsSnapshot(unittest.TestCase):
    def test_empty_network_returns_zeros(self):
        router = RoutingTable()
        ledger = IncentiveLedger(storage_path=None)
        snapshot = build_stats_snapshot(router, ledger)
        self.assertEqual(snapshot["summary"]["total_nodes"], 0)
        self.assertEqual(snapshot["nodes"], [])

    def test_nodes_sorted_by_points_descending(self):
        router = RoutingTable()
        ledger = IncentiveLedger(storage_path=None)
        for node_id in ["low", "high", "mid"]:
            router.register_block_owner(0, node_id)
            router.report_result(node_id, ok=True, latency_ms=50)

        ledger.record_success("low", complexity_multiplier=1)
        ledger.record_success("high", complexity_multiplier=10)
        ledger.record_success("mid", complexity_multiplier=5)

        snapshot = build_stats_snapshot(router, ledger)
        points_order = [n["points"] for n in snapshot["nodes"]]
        self.assertEqual(points_order, sorted(points_order, reverse=True))
        self.assertEqual(snapshot["nodes"][0]["node_id"], "high")

    def test_summary_averages_are_correct(self):
        router = RoutingTable()
        ledger = IncentiveLedger(storage_path=None)
        router.register_block_owner(0, "n1")
        router.register_block_owner(0, "n2")
        router.report_result("n1", ok=True, latency_ms=100)
        router.report_result("n2", ok=True, latency_ms=200)

        snapshot = build_stats_snapshot(router, ledger)
        # EWMA с alpha=0.3 от начального 200.0: 0.3*100 + 0.7*200 = 170 для n1
        #                                        0.3*200 + 0.7*200 = 200 для n2
        expected_avg = (170.0 + 200.0) / 2
        self.assertAlmostEqual(snapshot["summary"]["avg_latency_ms"], expected_avg, places=1)


class TestDashboardServerHTTP(unittest.TestCase):
    """Поднимает настоящий HTTP-сервер на localhost и делает реальные запросы."""

    def setUp(self):
        self.router = RoutingTable()
        self.ledger = IncentiveLedger(storage_path=None)
        self.router.register_block_owner(0, "nodeA")
        self.router.report_result("nodeA", ok=True, latency_ms=42)
        self.ledger.record_success("nodeA")

        self.server = DashboardServer(self.router, self.ledger, port=0)  # 0 = случайный свободный порт
        self.server.start()

    def tearDown(self):
        self.server.stop()

    def test_root_serves_html(self):
        with urllib.request.urlopen(f"http://127.0.0.1:{self.server.port}/") as resp:
            self.assertEqual(resp.status, 200)
            body = resp.read().decode("utf-8")
            self.assertIn("<html", body)
            self.assertIn("meshmind", body)

    def test_api_stats_serves_valid_json(self):
        with urllib.request.urlopen(f"http://127.0.0.1:{self.server.port}/api/stats") as resp:
            self.assertEqual(resp.status, 200)
            self.assertEqual(resp.headers["Content-Type"], "application/json")
            data = json.loads(resp.read().decode("utf-8"))
            self.assertEqual(data["summary"]["total_nodes"], 1)
            self.assertEqual(data["nodes"][0]["node_id"], "nodeA")

    def test_unknown_path_returns_404(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(f"http://127.0.0.1:{self.server.port}/nonexistent")
        self.assertEqual(ctx.exception.code, 404)

    def test_stats_reflect_live_changes(self):
        """Дашборд должен отражать изменения состояния роутера без перезапуска сервера."""
        with urllib.request.urlopen(f"http://127.0.0.1:{self.server.port}/api/stats") as resp:
            data_before = json.loads(resp.read().decode("utf-8"))
        self.assertEqual(data_before["summary"]["total_nodes"], 1)

        self.router.register_block_owner(0, "nodeB")
        self.router.report_result("nodeB", ok=True, latency_ms=10)

        with urllib.request.urlopen(f"http://127.0.0.1:{self.server.port}/api/stats") as resp:
            data_after = json.loads(resp.read().decode("utf-8"))
        self.assertEqual(data_after["summary"]["total_nodes"], 2)


if __name__ == "__main__":
    unittest.main()
