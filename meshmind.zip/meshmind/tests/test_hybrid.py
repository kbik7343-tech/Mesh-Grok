import unittest

from meshmind.hybrid.complexity import RouteTarget, decide_route, extract_signals
from meshmind.hybrid.cost_calculator import SONNET, UsageScenario, cost_all_cloud, cost_hybrid
from meshmind.hybrid.orchestrator import HybridOrchestrator, StubCloudModel, StubLocalModel


class TestComplexitySignals(unittest.TestCase):
    def test_detects_code_block(self):
        signals = extract_signals("напиши def foo(): pass")
        self.assertTrue(signals.has_code_block)

    def test_detects_recency_marker(self):
        signals = extract_signals("какие сейчас последние новости")
        self.assertTrue(signals.requires_recent_knowledge)

    def test_simple_prompt_has_no_flags(self):
        signals = extract_signals("привет")
        self.assertFalse(signals.has_code_block)
        self.assertFalse(signals.has_multi_step_markers)
        self.assertFalse(signals.requires_recent_knowledge)


class TestDecideRoute(unittest.TestCase):
    def test_offline_always_local_even_if_complex(self):
        decision = decide_route("напиши def foo(): сложный код", is_online=False)
        self.assertEqual(decision.target, RouteTarget.LOCAL)

    def test_simple_online_goes_local(self):
        decision = decide_route("привет", is_online=True)
        self.assertEqual(decision.target, RouteTarget.LOCAL)

    def test_code_goes_cloud(self):
        decision = decide_route("class Foo: def bar(self): pass", is_online=True)
        self.assertEqual(decision.target, RouteTarget.CLOUD)

    def test_long_prompt_goes_cloud(self):
        long_prompt = " ".join(["слово"] * 50)
        decision = decide_route(long_prompt, is_online=True)
        self.assertEqual(decision.target, RouteTarget.CLOUD)

    def test_custom_token_threshold_respected(self):
        prompt = " ".join(["слово"] * 10)
        # При пороге 5 даже короткий (по умолчанию) промпт станет "длинным"
        decision = decide_route(prompt, is_online=True, token_threshold=5)
        self.assertEqual(decision.target, RouteTarget.CLOUD)


class TestHybridOrchestrator(unittest.TestCase):
    def test_routes_to_local_stub_for_simple_prompt(self):
        orch = HybridOrchestrator(
            local_model=StubLocalModel(),
            cloud_model=StubCloudModel(),
            is_online_check=lambda: True,
        )
        result = orch.answer("привет")
        self.assertIn("локальный", result)

    def test_routes_to_cloud_stub_for_complex_prompt(self):
        orch = HybridOrchestrator(
            local_model=StubLocalModel(),
            cloud_model=StubCloudModel(),
            is_online_check=lambda: True,
        )
        result = orch.answer("напиши def foo(): сложную функцию")
        self.assertIn("облачный", result)

    def test_forces_local_when_offline_check_returns_false(self):
        orch = HybridOrchestrator(
            local_model=StubLocalModel(),
            cloud_model=StubCloudModel(),
            is_online_check=lambda: False,  # имитация отсутствия сети
        )
        result = orch.answer("напиши def foo(): сложную функцию")
        self.assertIn("локальный", result, "Офлайн должен форсировать локальную модель даже для сложного запроса")

    def test_last_decision_recorded(self):
        orch = HybridOrchestrator(
            local_model=StubLocalModel(),
            cloud_model=StubCloudModel(),
            is_online_check=lambda: True,
        )
        orch.answer("привет")
        self.assertIsNotNone(orch.last_decision)
        self.assertEqual(orch.last_decision.target, RouteTarget.LOCAL)


class TestCostCalculator(unittest.TestCase):
    def setUp(self):
        self.scenario = UsageScenario(
            name="test",
            daily_active_users=1000,
            queries_per_user_per_day=10,
            avg_input_tokens=100,
            avg_output_tokens=200,
            local_share=0.5,
            cloud_pricing=SONNET,
        )

    def test_hybrid_cheaper_than_all_cloud(self):
        self.assertLess(cost_hybrid(self.scenario), cost_all_cloud(self.scenario))

    def test_zero_local_share_equals_all_cloud_cost(self):
        import dataclasses
        scenario = dataclasses.replace(self.scenario, local_share=0.0)
        self.assertAlmostEqual(cost_hybrid(scenario), cost_all_cloud(scenario), places=2)

    def test_full_local_share_means_zero_cloud_cost(self):
        import dataclasses
        scenario = dataclasses.replace(self.scenario, local_share=1.0)
        self.assertAlmostEqual(cost_hybrid(scenario), 0.0, places=2)

    def test_savings_proportional_to_local_share(self):
        import dataclasses
        scenario_30 = dataclasses.replace(self.scenario, local_share=0.3)
        scenario_70 = dataclasses.replace(self.scenario, local_share=0.7)

        savings_30 = cost_all_cloud(scenario_30) - cost_hybrid(scenario_30)
        savings_70 = cost_all_cloud(scenario_70) - cost_hybrid(scenario_70)
        self.assertLess(savings_30, savings_70)


if __name__ == "__main__":
    unittest.main()
