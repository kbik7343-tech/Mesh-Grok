import unittest

from meshmind.hybrid.speculative import run_full_generation, speculative_generate


class TestSpeculativeGenerate(unittest.TestCase):
    def test_all_tokens_accepted(self):
        def draft_fn(context, k):
            return ["A", "B", "C"][:k]

        def verify_fn(context, draft):
            return [True] * len(draft)  # большая модель согласна со всем черновиком

        result = speculative_generate([], draft_fn, verify_fn, num_speculative_tokens=3)
        self.assertEqual(result.accepted_tokens, ["A", "B", "C"])
        self.assertIsNone(result.rejected_at)
        self.assertEqual(result.num_accepted, 3)

    def test_partial_rejection_stops_at_first_mismatch(self):
        def draft_fn(context, k):
            return ["A", "B", "C", "D"][:k]

        def verify_fn(context, draft):
            return [True, True, False, True]  # расхождение на индексе 2

        result = speculative_generate([], draft_fn, verify_fn, num_speculative_tokens=4)
        self.assertEqual(result.accepted_tokens, ["A", "B"])
        self.assertEqual(result.rejected_at, 2)
        # Токен D после расхождения не должен попасть в accepted,
        # даже если verify_fn вернула для него True — контекст для него был неверный
        self.assertNotIn("D", result.accepted_tokens)

    def test_immediate_rejection(self):
        def draft_fn(context, k):
            return ["X"]

        def verify_fn(context, draft):
            return [False]

        result = speculative_generate([], draft_fn, verify_fn, num_speculative_tokens=1)
        self.assertEqual(result.accepted_tokens, [])
        self.assertEqual(result.rejected_at, 0)

    def test_empty_draft_handled(self):
        def draft_fn(context, k):
            return []

        def verify_fn(context, draft):
            return []

        result = speculative_generate([], draft_fn, verify_fn)
        self.assertEqual(result.num_drafted, 0)
        self.assertEqual(result.network_calls_saved, 0)

    def test_mismatched_lengths_raise(self):
        def draft_fn(context, k):
            return ["A", "B"]

        def verify_fn(context, draft):
            return [True]  # длина не совпадает с draft (2 токена)

        with self.assertRaises(ValueError):
            speculative_generate([], draft_fn, verify_fn, num_speculative_tokens=2)

    def test_network_calls_saved_counts_correctly(self):
        """
        Без spec decoding: 3 принятых + 1 для расхождения = 4 отдельных
        сетевых вызова. С spec decoding — 1 вызов verify_fn. Экономия = 3.
        """
        def draft_fn(context, k):
            return ["A", "B", "C", "D"]

        def verify_fn(context, draft):
            return [True, True, True, False]

        result = speculative_generate([], draft_fn, verify_fn, num_speculative_tokens=4)
        self.assertEqual(result.network_calls_saved, 3)


class TestRunFullGeneration(unittest.TestCase):
    def test_generates_exact_requested_length(self):
        # Детерминированный "большой словарь" — draft всегда верный, кроме каждого 5-го токена
        correct_sequence = list("ABCDEFGHIJ")

        def draft_fn(context, k):
            pos = len(context)
            return correct_sequence[pos:pos + k]

        def verify_fn(context, draft):
            pos = len(context)
            return [
                correct_sequence[pos + i] == tok if pos + i < len(correct_sequence) else False
                for i, tok in enumerate(draft)
            ]

        def fallback_fn(context):
            pos = len(context)
            return correct_sequence[pos] if pos < len(correct_sequence) else "?"

        generated, saved = run_full_generation(
            [], draft_fn, verify_fn, fallback_fn, max_tokens=10, num_speculative_tokens=4
        )
        self.assertEqual(generated, correct_sequence)
        self.assertEqual(len(generated), 10)

    def test_savings_are_positive_when_draft_is_good(self):
        correct_sequence = list("ABCDEFGH")

        def draft_fn(context, k):
            pos = len(context)
            return correct_sequence[pos:pos + k]

        def verify_fn(context, draft):
            pos = len(context)
            return [correct_sequence[pos + i] == tok for i, tok in enumerate(draft)]

        def fallback_fn(context):
            pos = len(context)
            return correct_sequence[pos] if pos < len(correct_sequence) else "?"

        _, saved = run_full_generation(
            [], draft_fn, verify_fn, fallback_fn, max_tokens=8, num_speculative_tokens=4
        )
        self.assertGreater(saved, 0, "При хорошем черновике должна быть реальная экономия вызовов")

    def test_always_wrong_draft_still_terminates(self):
        """Даже если черновик ВСЕГДА неверный, генерация не должна зависнуть — fallback двигает вперёд."""
        call_count = {"fallback": 0}

        def draft_fn(context, k):
            return ["WRONG"] * k

        def verify_fn(context, draft):
            return [False] * len(draft)

        def fallback_fn(context):
            call_count["fallback"] += 1
            return f"real_{len(context)}"

        generated, saved = run_full_generation(
            [], draft_fn, verify_fn, fallback_fn, max_tokens=5, num_speculative_tokens=3
        )
        self.assertEqual(len(generated), 5)
        self.assertEqual(call_count["fallback"], 5)  # каждый токен пришлось брать через fallback


if __name__ == "__main__":
    unittest.main()
