import tempfile
import unittest
from pathlib import Path

from meshmind.incentives import IncentiveLedger


class TestIncentiveLedger(unittest.TestCase):
    def setUp(self):
        self.ledger = IncentiveLedger(storage_path=None)  # без записи на диск

    def test_success_adds_points(self):
        self.ledger.record_success("nodeA")
        self.assertEqual(self.ledger._get("nodeA").points, 1.0)

    def test_complexity_multiplier_scales_points(self):
        self.ledger.record_success("nodeA", complexity_multiplier=3.0)
        self.assertEqual(self.ledger._get("nodeA").points, 3.0)

    def test_failure_reduces_points_but_not_below_zero(self):
        self.ledger.record_failure("nodeA")
        self.assertEqual(self.ledger._get("nodeA").points, 0.0)  # не уходит в минус

    def test_priority_tiers(self):
        rec = self.ledger._get("gold_node")
        rec.points = 1500
        rec.served_requests = 100
        self.assertEqual(rec.priority_tier, "gold")

        rec2 = self.ledger._get("silver_node")
        rec2.points = 150
        self.assertEqual(rec2.priority_tier, "silver")

        rec3 = self.ledger._get("bronze_node")
        rec3.points = 10
        self.assertEqual(rec3.priority_tier, "bronze")

    def test_gold_requires_high_reliability_not_just_points(self):
        # Много очков, но низкая надёжность — не должен быть gold
        rec = self.ledger._get("unreliable_but_rich")
        rec.points = 2000
        rec.served_requests = 50
        rec.failed_requests = 50  # 50% надёжность
        self.assertNotEqual(rec.priority_tier, "gold")

    def test_priority_order_sorts_gold_first(self):
        self.ledger._get("bronze").points = 5
        gold = self.ledger._get("gold")
        gold.points = 1200
        gold.served_requests = 200

        order = self.ledger.priority_order(["bronze", "gold"])
        self.assertEqual(order[0], "gold")

    def test_persistence_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ledger.json"
            ledger1 = IncentiveLedger(storage_path=str(path))
            ledger1.record_success("nodeX", complexity_multiplier=2.0)

            ledger2 = IncentiveLedger(storage_path=str(path))  # перезагрузка с диска
            self.assertEqual(ledger2._get("nodeX").points, 2.0)


if __name__ == "__main__":
    unittest.main()
