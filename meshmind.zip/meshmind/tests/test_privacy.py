import unittest

from meshmind.privacy import HopEncryption, TrustPolicy, add_privacy_noise


class TestHopEncryption(unittest.TestCase):
    def test_encrypt_decrypt_roundtrip(self):
        enc = HopEncryption()
        original = b"secret activations tensor data"
        blob = enc.encrypt(original)
        self.assertEqual(enc.decrypt(blob), original)

    def test_ciphertext_differs_from_plaintext(self):
        enc = HopEncryption()
        original = b"plain data"
        blob = enc.encrypt(original)
        self.assertNotEqual(blob, original)

    def test_different_nonce_each_call(self):
        enc = HopEncryption()
        blob1 = enc.encrypt(b"same message")
        blob2 = enc.encrypt(b"same message")
        self.assertNotEqual(blob1, blob2, "Разные nonce должны давать разный шифротекст для одного сообщения")

    def test_wrong_key_fails_to_decrypt(self):
        enc1 = HopEncryption()
        enc2 = HopEncryption()  # другой случайный ключ
        blob = enc1.encrypt(b"secret")
        with self.assertRaises(Exception):
            enc2.decrypt(blob)

    def test_shared_session_key_works_both_ways(self):
        shared_key = HopEncryption().key
        sender = HopEncryption(session_key=shared_key)
        receiver = HopEncryption(session_key=shared_key)
        blob = sender.encrypt(b"hop message")
        self.assertEqual(receiver.decrypt(blob), b"hop message")


class TestPrivacyNoise(unittest.TestCase):
    def test_noise_changes_values(self):
        original = [1.0, 2.0, 3.0]
        noisy = add_privacy_noise(original, epsilon=1.0)
        self.assertNotEqual(original, noisy)
        self.assertEqual(len(original), len(noisy))

    def test_lower_epsilon_means_more_noise(self):
        import statistics

        original = [5.0] * 200
        low_privacy = add_privacy_noise(original, epsilon=10.0)   # мало шума
        high_privacy = add_privacy_noise(original, epsilon=0.1)   # много шума

        low_spread = statistics.pstdev(low_privacy)
        high_spread = statistics.pstdev(high_privacy)
        self.assertGreater(high_spread, low_spread, "Меньший epsilon должен давать больший разброс шума")


class TestTrustPolicy(unittest.TestCase):
    def test_untrusted_by_default(self):
        policy = TrustPolicy()
        self.assertFalse(policy.is_trusted("nodeA"))

    def test_mark_and_filter_trusted(self):
        policy = TrustPolicy()
        policy.mark_trusted("nodeA")
        policy.mark_trusted("nodeB")
        filtered = policy.filter_trusted(["nodeA", "nodeB", "nodeC"])
        self.assertEqual(set(filtered), {"nodeA", "nodeB"})
        self.assertNotIn("nodeC", filtered)


if __name__ == "__main__":
    unittest.main()
