#!/usr/bin/env bash
# Запуск всего набора тестов. Не требует pytest — только стандартная
# библиотека Python (unittest), так что работает везде из коробки.
set -e
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -v
