"""
incentives.py — учёт вклада узлов и приоритеты доступа.

Аналог "bloom points" в Petals, но проще и прозрачнее: узел получает
очки за каждый успешно обслуженный запрос (пропорционально сложности
и надёжности), а очки конвертируются в приоритет в очереди роутера
при высокой нагрузке сети. Никакой блокчейн-инфраструктуры не нужно —
это локальный (или централизованный на координаторе) реестр репутации.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass
class ContributionRecord:
    node_id: str
    points: float = 0.0
    served_requests: int = 0
    failed_requests: int = 0
    first_seen: float = field(default_factory=time.time)

    @property
    def reliability(self) -> float:
        total = self.served_requests + self.failed_requests
        return self.served_requests / total if total else 1.0

    @property
    def priority_tier(self) -> str:
        """Простая многоуровневая система приоритета вместо аукциона/платы."""
        if self.points >= 1000 and self.reliability >= 0.95:
            return "gold"     # первым получает запросы, приоритет в очередях
        if self.points >= 100:
            return "silver"
        return "bronze"       # новички — базовый уровень, без штрафов


class IncentiveLedger:
    """
    Локальный реестр очков. В однонодовом/приватном рое достаточно
    файла на координаторе; для публичного роя это можно заменить на
    любую БД или распределённый реестр — интерфейс не меняется.
    """

    POINTS_PER_SUCCESS = 1.0
    POINTS_PENALTY_PER_FAILURE = 0.5

    def __init__(self, storage_path: str | None = None) -> None:
        self._records: dict[str, ContributionRecord] = {}
        self._storage_path = Path(storage_path) if storage_path else None
        if self._storage_path and self._storage_path.exists():
            self._load()

    def _load(self) -> None:
        data = json.loads(self._storage_path.read_text())
        for node_id, rec in data.items():
            self._records[node_id] = ContributionRecord(**rec)

    def _save(self) -> None:
        if not self._storage_path:
            return
        data = {nid: asdict(rec) for nid, rec in self._records.items()}
        self._storage_path.write_text(json.dumps(data, indent=2))

    def _get(self, node_id: str) -> ContributionRecord:
        return self._records.setdefault(node_id, ContributionRecord(node_id=node_id))

    def record_success(self, node_id: str, complexity_multiplier: float = 1.0) -> None:
        rec = self._get(node_id)
        rec.points += self.POINTS_PER_SUCCESS * complexity_multiplier
        rec.served_requests += 1
        self._save()

    def record_failure(self, node_id: str) -> None:
        rec = self._get(node_id)
        rec.points = max(0.0, rec.points - self.POINTS_PENALTY_PER_FAILURE)
        rec.failed_requests += 1
        self._save()

    def priority_order(self, node_ids: list[str]) -> list[str]:
        """Сортирует узлы по приоритету — используется роутером при перегрузке сети."""
        tier_rank = {"gold": 0, "silver": 1, "bronze": 2}
        return sorted(
            node_ids,
            key=lambda n: (tier_rank[self._get(n).priority_tier], -self._get(n).points),
        )

    def leaderboard(self, top: int = 10) -> list[str]:
        ranked = sorted(self._records.values(), key=lambda r: r.points, reverse=True)
        return [
            f"{r.node_id}: {r.points:.1f} очков · {r.priority_tier} · "
            f"надёжность {r.reliability:.0%}"
            for r in ranked[:top]
        ]
