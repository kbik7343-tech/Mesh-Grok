"""
server.py — веб-дашборд живого состояния сети: узлы, их здоровье
(задержка/надёжность/нагрузка из router.py) и вклад (очки/приоритет
из incentives.py). Сознательно на чистой stdlib (http.server) — без
Flask/FastAPI/aiohttp, чтобы не зависеть от интернета для установки
и чтобы дашборд можно было поднять где угодно без пересборки окружения.

Архитектура: ThreadingHTTPServer в отдельном потоке, два эндпоинта —
GET /           -> HTML-страница с авто-обновлением (vanilla JS, poll раз в секунду)
GET /api/stats  -> JSON-снимок состояния router.py + incentives.py

Обновление "живое" в смысле реального опроса состояния сервера, но не
push/websocket — простой polling, который полностью достаточен для
дашборда мониторинга (секундная задержка не критична), и его на
порядок проще протестировать и поддерживать, чем websocket-сервер.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from ..incentives import IncentiveLedger
from ..router import RoutingTable

_DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>meshmind — мониторинг сети</title>
<style>
  body { font-family: -apple-system, sans-serif; margin: 0; padding: 20px; background: #0d1117; color: #e6edf3; }
  h1 { font-size: 18px; font-weight: 500; margin: 0 0 16px; }
  .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 20px; }
  .card { background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 12px; }
  .card .label { font-size: 12px; color: #8b949e; }
  .card .value { font-size: 22px; font-weight: 500; margin-top: 4px; }
  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th, td { text-align: left; padding: 8px; border-bottom: 1px solid #30363d; }
  th { color: #8b949e; font-weight: 500; }
  .bar-bg { background: #30363d; border-radius: 4px; height: 6px; width: 80px; overflow: hidden; }
  .bar-fill { height: 100%; border-radius: 4px; }
  .tier-gold { color: #e3b341; }
  .tier-silver { color: #c9d1d9; }
  .tier-bronze { color: #d29a5f; }
  .updated { font-size: 11px; color: #6e7681; margin-top: 12px; }
</style>
</head>
<body>
  <h1>meshmind — состояние сети</h1>
  <div class="cards" id="cards"></div>
  <table>
    <thead><tr><th>Узел</th><th>Задержка</th><th>Надёжность</th><th>Нагрузка</th><th>Очки</th><th>Уровень</th></tr></thead>
    <tbody id="rows"></tbody>
  </table>
  <div class="updated" id="updated"></div>

<script>
async function refresh() {
  try {
    const res = await fetch('/api/stats');
    const data = await res.json();

    const cards = document.getElementById('cards');
    cards.innerHTML = `
      <div class="card"><div class="label">Узлов в сети</div><div class="value">${data.summary.total_nodes}</div></div>
      <div class="card"><div class="label">Средняя задержка</div><div class="value">${Math.round(data.summary.avg_latency_ms)} мс</div></div>
      <div class="card"><div class="label">Средняя надёжность</div><div class="value">${Math.round(data.summary.avg_success_rate * 100)}%</div></div>
      <div class="card"><div class="label">Активных запросов</div><div class="value">${data.summary.total_active_requests}</div></div>
    `;

    const rows = document.getElementById('rows');
    rows.innerHTML = data.nodes.map(n => `
      <tr>
        <td>${n.node_id}</td>
        <td>
          <div class="bar-bg"><div class="bar-fill" style="width:${Math.min(100, n.latency_ms/5)}%; background:${n.latency_ms < 100 ? '#3fb950' : n.latency_ms < 300 ? '#d29922' : '#f85149'}"></div></div>
          ${Math.round(n.latency_ms)} мс
        </td>
        <td>${Math.round(n.success_rate * 100)}%</td>
        <td>${n.active_requests}</td>
        <td>${n.points.toFixed(1)}</td>
        <td class="tier-${n.tier}">${n.tier}</td>
      </tr>
    `).join('');

    document.getElementById('updated').textContent = 'Обновлено: ' + new Date().toLocaleTimeString('ru-RU');
  } catch (e) {
    document.getElementById('updated').textContent = 'Ошибка подключения к дашборду';
  }
}
refresh();
setInterval(refresh, 1000);
</script>
</body>
</html>
"""


def build_stats_snapshot(router: RoutingTable, ledger: IncentiveLedger) -> dict:
    """
    Собирает JSON-снимок состояния сети из router.py и incentives.py.
    Вынесено в отдельную функцию (не внутрь HTTP-хендлера), чтобы
    можно было протестировать формирование данных без реального
    HTTP-запроса — это и есть основная тестируемая логика дашборда.
    """
    nodes = []
    for node_id, health in router._health.items():
        rec = ledger._get(node_id)
        nodes.append({
            "node_id": node_id,
            "latency_ms": health.ewma_latency_ms,
            "success_rate": health.success_rate,
            "active_requests": health.active_requests,
            "points": rec.points,
            "tier": rec.priority_tier,
        })

    nodes.sort(key=lambda n: n["points"], reverse=True)

    if nodes:
        avg_latency = sum(n["latency_ms"] for n in nodes) / len(nodes)
        avg_success = sum(n["success_rate"] for n in nodes) / len(nodes)
    else:
        avg_latency = 0.0
        avg_success = 0.0

    return {
        "nodes": nodes,
        "summary": {
            "total_nodes": len(nodes),
            "avg_latency_ms": avg_latency,
            "avg_success_rate": avg_success,
            "total_active_requests": sum(n["active_requests"] for n in nodes),
        },
    }


def _make_handler(router: RoutingTable, ledger: IncentiveLedger):
    class DashboardHandler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args) -> None:
            pass  # отключаем шумный стандартный лог в stderr на каждый запрос

        def do_GET(self) -> None:
            if self.path == "/":
                body = _DASHBOARD_HTML.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            elif self.path == "/api/stats":
                snapshot = build_stats_snapshot(router, ledger)
                body = json.dumps(snapshot).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            else:
                self.send_response(404)
                self.end_headers()

    return DashboardHandler


class DashboardServer:
    """Обёртка для запуска/остановки дашборда в фоновом потоке."""

    def __init__(self, router: RoutingTable, ledger: IncentiveLedger, host: str = "127.0.0.1", port: int = 0):
        handler = _make_handler(router, ledger)
        self._httpd = ThreadingHTTPServer((host, port), handler)
        self._thread: threading.Thread | None = None

    @property
    def port(self) -> int:
        return self._httpd.server_address[1]

    def start(self) -> None:
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()
        if self._thread:
            self._thread.join(timeout=2.0)


if __name__ == "__main__":
    import random
    import time

    router = RoutingTable()
    ledger = IncentiveLedger(storage_path=None)

    # Демо-данные для ручного просмотра
    for i in range(8):
        node_id = f"node-{i}"
        router.register_block_owner(0, node_id)
        router.report_result(node_id, ok=True, latency_ms=random.uniform(20, 400))
        ledger.record_success(node_id, complexity_multiplier=random.uniform(0.5, 3))

    server = DashboardServer(router, ledger, port=8765)
    server.start()
    print(f"Дашборд запущен: http://127.0.0.1:{server.port}")
    print("Ctrl+C для остановки")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        server.stop()
