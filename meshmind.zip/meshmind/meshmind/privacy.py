"""
privacy.py — защита данных при передаче между узлами.

ВАЖНО, честно: раз каждый узел физически выполняет вычисления над
своим блоком модели, он обязан видеть промежуточные активации в
открытом виде для матричного умножения — сквозное (end-to-end)
шифрование данных, обрабатываемых чужим железом, невозможно без
гомоморфного шифрования (которое на 3-4 порядка медленнее и для
LLM-инференса пока непрактично). Здесь работают два реалистичных
уровня защиты:

  1. Транспортное шифрование (hop-to-hop) — каждый прыжок между узлами
     защищён, так что данные не может перехватить кто-то посторонний
     в сети (сниффер трафика, MITM). Сам узел-получатель данные видит.
  2. Опциональный шум (differential-privacy-style) — на клиенте можно
     добавить контролируемый шум к активациям перед отправкой в
     недоверенные узлы, снижая точность реконструкции входа ценой
     небольшой потери качества генерации. Это компромисс, который
     явно выбирает пользователь, а не "решение всех проблем".

Вывод для UI/документации продукта: чувствительные данные должны идти
через приватный рой доверенных узлов (см. incentives.py — можно
задать "trusted-only" фильтр), публичный рой годится для несекретных
задач — так же, как честно предупреждает сам Petals.
"""

from __future__ import annotations

import os

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False


class HopEncryption:
    """
    Шифрование одного "прыжка" точка-точка между клиентом/узлом и
    следующим узлом. Каждый прыжок использует свой сессионный ключ
    (получаемый, например, через X25519 key exchange при рукопожатии —
    здесь для краткости ключ передаётся напрямую, в реальной системе
    его нужно согласовывать через защищённый handshake).
    """

    def __init__(self, session_key: bytes | None = None) -> None:
        if not _HAS_CRYPTO:
            raise RuntimeError(
                "Требуется пакет 'cryptography': pip install cryptography"
            )
        self._key = session_key or AESGCM.generate_key(bit_length=256)
        self._aead = AESGCM(self._key)

    @property
    def key(self) -> bytes:
        return self._key

    def encrypt(self, payload: bytes) -> bytes:
        nonce = os.urandom(12)
        return nonce + self._aead.encrypt(nonce, payload, associated_data=None)

    def decrypt(self, blob: bytes) -> bytes:
        nonce, ciphertext = blob[:12], blob[12:]
        return self._aead.decrypt(nonce, ciphertext, associated_data=None)


def add_privacy_noise(activations: "list[float]", epsilon: float = 1.0) -> "list[float]":
    """
    Добавляет калиброванный шум Лапласа к промежуточным активациям —
    компромисс между приватностью входа и точностью вывода модели.
    Меньший epsilon = больше шума = сильнее приватность, слабее качество.

    Это НЕ формальная дифференциальная приватность всей системы (для
    этого нужен строгий бюджет приватности на всех этапах), а
    практическая мера снижения риска реконструкции исходного текста
    недоверенным промежуточным узлом.
    """
    import random

    scale = 1.0 / max(epsilon, 0.01)
    return [x + random.gauss(0, scale) for x in activations]


class TrustPolicy:
    """
    Простой фильтр: помечает узлы как 'trusted' (свои/проверенные) или
    'public' (произвольные добровольцы). Роутер (router.py) может
    получить список только доверенных узлов для чувствительных задач.
    """

    def __init__(self) -> None:
        self._trusted: set[str] = set()

    def mark_trusted(self, node_id: str) -> None:
        self._trusted.add(node_id)

    def is_trusted(self, node_id: str) -> bool:
        return node_id in self._trusted

    def filter_trusted(self, node_ids: list[str]) -> list[str]:
        return [n for n in node_ids if n in self._trusted]
