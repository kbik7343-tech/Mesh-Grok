"""
commit_verify.py — верификация, что узел честно выполнил вычисление,
БЕЗ настоящих zero-knowledge proofs (zkML требует специализированных
библиотек вроде ezkl/EZKL или circom, которых здесь нет, и даже с
ними инференс LLM через zk-SNARK на 2-3 порядка медленнее обычного —
на практике это пока не применяют к большим моделям).

Вместо этого — две более простые, но реальные техники:

1. COMMIT-REVEAL: узел публикует хэш своего результата ДО того, как
   раскрывает сами данные. Это не доказывает корректность вычисления,
   но доказывает, что узел не поменял ответ задним числом, узнав
   "правильный" от кого-то другого (защита от сговора/копирования).

2. SPOT-CHECKING: координатор со случайной вероятностью p повторяет
   чей-то расчёт на доверенном узле и сравнивает результат. Если узел
   обманывает с вероятностью q на каждый запрос, вероятность поимки
   после n запросов растёт как 1-(1-p)^n — при p=0.1 и 100 запросах
   шанс ни разу не попасться — меньше 0.003%. Это statistical
   guarantee, а не cryptographic proof, но для экономических стимулов
   (нечестный узел теряет репутацию/очки) этого часто достаточно —
   похожий механизм использует Bittensor.
"""

from __future__ import annotations

import hashlib
import random
import time
from dataclasses import dataclass, field


def commit(data: bytes, nonce: bytes) -> str:
    """Хэш-обязательство: узел публикует ЭТО до раскрытия data."""
    return hashlib.sha256(nonce + data).hexdigest()


def verify_commitment(data: bytes, nonce: bytes, committed_hash: str) -> bool:
    """Проверка, что раскрытые data+nonce действительно дают ранее опубликованный хэш."""
    return commit(data, nonce) == committed_hash


@dataclass
class ComputationRecord:
    """Один зафиксированный расчёт узла — для последующей выборочной перепроверки."""

    request_id: str
    node_id: str
    input_hash: str              # хэш входных данных (не сами данные — экономия памяти)
    committed_output_hash: str   # обязательство по результату, опубликованное ДО раскрытия
    revealed_output: bytes | None = None
    revealed_nonce: bytes | None = None
    verified: bool | None = None  # None = не проверялось, True/False = результат перепроверки
    timestamp: float = field(default_factory=time.time)


class SpotCheckVerifier:
    """
    Координатор верификации: решает, когда перепроверять узел, и ведёт
    статистику по уличённым в обмане. check_probability настраивает
    баланс между накладными расходами (перепроверка = двойная работа)
    и скоростью обнаружения нечестных узлов.
    """

    def __init__(self, check_probability: float = 0.1, rng: random.Random | None = None):
        self.check_probability = check_probability
        self._rng = rng or random.Random()
        self._records: dict[str, ComputationRecord] = {}
        self._caught_cheating: dict[str, int] = {}

    def should_spot_check(self) -> bool:
        return self._rng.random() < self.check_probability

    def record_commitment(self, request_id: str, node_id: str, input_data: bytes,
                           output: bytes, nonce: bytes) -> ComputationRecord:
        """Узел прислал результат вместе с обязательством — фиксируем для возможной проверки."""
        record = ComputationRecord(
            request_id=request_id,
            node_id=node_id,
            input_hash=hashlib.sha256(input_data).hexdigest(),
            committed_output_hash=commit(output, nonce),
            revealed_output=output,
            revealed_nonce=nonce,
        )
        self._records[request_id] = record
        return record

    def spot_check(self, request_id: str, trusted_recomputation: bytes) -> bool:
        """
        Сравнивает результат узла с результатом доверенного пересчёта.
        Возвращает True, если узел честен (результаты совпали).
        """
        record = self._records.get(request_id)
        if record is None or record.revealed_output is None:
            raise ValueError(f"Нет записи для перепроверки запроса {request_id}")

        # Сначала проверяем, что раскрытые данные соответствуют обязательству —
        # иначе узел мог бы просто подставить trusted_recomputation задним числом.
        commitment_valid = verify_commitment(
            record.revealed_output, record.revealed_nonce, record.committed_output_hash
        )
        results_match = record.revealed_output == trusted_recomputation

        honest = commitment_valid and results_match
        record.verified = honest

        if not honest:
            self._caught_cheating[record.node_id] = self._caught_cheating.get(record.node_id, 0) + 1

        return honest

    def cheating_count(self, node_id: str) -> int:
        return self._caught_cheating.get(node_id, 0)

    def is_flagged(self, node_id: str, threshold: int = 2) -> bool:
        """Узел с threshold+ пойманными обманами должен быть исключён из сети."""
        return self.cheating_count(node_id) >= threshold
