"""
ratelimit.py — защита от спама запросов через token bucket на
каждого клиента (по node_id клиента или IP). Это защищает узлы сети
от одного недобросовестного или сломанного клиента, заваливающего
их запросами — отдельная задача от router.py (который защищает от
ПЛОХИХ узлов, а не от перегрузки ХОРОШИХ клиентами).

Token bucket выбран вместо простого "N запросов в минуту", потому
что он допускает короткие всплески (burst) — что естественно для
чата (пользователь быстро отправил 3 сообщения подряд), но всё
равно ограничивает устойчивую нагрузку.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class TokenBucket:
    """
    capacity — максимум токенов в ведре (= максимальный размер всплеска).
    refill_rate — токенов в секунду, восполняющихся со временем.
    """

    capacity: float
    refill_rate: float
    _tokens: float = field(init=False)
    _last_refill: float = field(init=False, default_factory=time.time)

    def __post_init__(self) -> None:
        self._tokens = self.capacity  # ведро стартует полным

    def _refill(self) -> None:
        now = time.time()
        elapsed = now - self._last_refill
        self._tokens = min(self.capacity, self._tokens + elapsed * self.refill_rate)
        self._last_refill = now

    def try_consume(self, cost: float = 1.0) -> bool:
        """Пытается списать cost токенов. Возвращает True, если хватило (запрос разрешён)."""
        self._refill()
        if self._tokens >= cost:
            self._tokens -= cost
            return True
        return False

    def time_until_available(self, cost: float = 1.0) -> float:
        """Сколько секунд ждать, пока наберётся cost токенов (для сообщения 'повтори через X сек')."""
        self._refill()
        if self._tokens >= cost:
            return 0.0
        missing = cost - self._tokens
        return missing / self.refill_rate


class RateLimiter:
    """
    Реестр ведёр по клиентам — создаётся лениво при первом запросе
    клиента, без необходимости заранее знать список всех клиентов.
    """

    def __init__(self, capacity: float = 20.0, refill_rate: float = 2.0):
        self._capacity = capacity
        self._refill_rate = refill_rate
        self._buckets: dict[str, TokenBucket] = {}

    def _bucket_for(self, client_id: str) -> TokenBucket:
        if client_id not in self._buckets:
            self._buckets[client_id] = TokenBucket(self._capacity, self._refill_rate)
        return self._buckets[client_id]

    def allow(self, client_id: str, cost: float = 1.0) -> bool:
        return self._bucket_for(client_id).try_consume(cost)

    def retry_after(self, client_id: str, cost: float = 1.0) -> float:
        return self._bucket_for(client_id).time_until_available(cost)

    def reset(self, client_id: str) -> None:
        """Явный сброс (например, после подтверждения, что клиент не злонамеренный)."""
        self._buckets.pop(client_id, None)

    def active_clients(self) -> int:
        return len(self._buckets)
