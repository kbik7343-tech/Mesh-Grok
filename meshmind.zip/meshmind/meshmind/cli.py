"""
cli.py — упрощённая установка и запуск узла.

Улучшение над Petals в этом пункте: у них запуск узла требует
Anaconda/Docker, ручной установки CUDA-toolkit и знания, какую модель
указать в команде. Здесь — один мастер, который сам определяет
возможности машины и предлагает разумную конфигурацию, плюс отдельная
команда для приватного роя без лишних шагов.

Использование:
    python -m meshmind.cli setup      # интерактивный мастер первого запуска
    python -m meshmind.cli start      # запуск узла с сохранённой конфигурацией
    python -m meshmind.cli status     # текущее состояние узла и сети
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from .incentives import IncentiveLedger
from .node import NodeInfo
from .service import MeshService, ServiceConfig

CONFIG_PATH = Path.home() / ".meshmind" / "config.json"


def _ensure_config_dir() -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)


def cmd_setup(_args: argparse.Namespace) -> None:
    print("Мастер установки meshmind\n" + "-" * 30)
    info = NodeInfo()
    print("Определены характеристики устройства:")
    print(" ", info.summary())

    caps = info.capabilities
    if caps.ram_gb and caps.ram_gb < 8:
        print(
            "\nПримечание: меньше 8 ГБ RAM — узел сможет держать лишь "
            "небольшую часть модели. Это нормально, сеть распределит "
            "нагрузку с учётом этого (см. router.py)."
        )
    if not caps.has_gpu:
        print(
            "GPU не обнаружен — узел будет работать медленнее, но всё "
            "равно полезен сети (например, для лёгких блоков или как "
            "резервный маршрут)."
        )

    swarm_type = input(
        "\nК какому рою подключиться? [public/private] (по умолчанию public): "
    ).strip().lower() or "public"

    config = {
        "node_id": info.node_id,
        "swarm_type": swarm_type,
        "ram_gb": caps.ram_gb,
        "has_gpu": caps.has_gpu,
        "capacity_score": caps.estimated_capacity_score(),
    }

    _ensure_config_dir()
    CONFIG_PATH.write_text(json.dumps(config, indent=2, ensure_ascii=False))
    print(f"\nГотово. Конфигурация сохранена в {CONFIG_PATH}")
    print("Запусти узел командой: python -m meshmind.cli start")


def cmd_start(args: argparse.Namespace) -> None:
    """
    Полноценный запуск узла — поднимает ВСЕ подсистемы разом
    (транспорт, gossip-обнаружение, rate limiting, верификацию,
    дашборд). Это не заглушка, как раньше, а реальный сервис.
    """
    if not CONFIG_PATH.exists():
        print("Конфигурация не найдена. Сначала выполни: python -m meshmind.cli setup")
        sys.exit(1)

    saved_config = json.loads(CONFIG_PATH.read_text())

    async def run():
        service = MeshService(ServiceConfig(
            node_id=saved_config["node_id"],
            dashboard_port=None if args.no_dashboard else 8765,
        ))
        await service.start()

        print(f"Узел {service.info.node_id} запущен")
        print(f"  Транспорт (принимает запросы):  127.0.0.1:{service.transport_port}")
        print(f"  Gossip (обнаружение сети):      127.0.0.1:{service.gossip_port}")
        if service.dashboard_url:
            print(f"  Дашборд мониторинга:             {service.dashboard_url}")

        if args.join:
            seed_host, seed_port = args.join.split(":")
            await service.join_network(seed_host, int(seed_port))
            print(f"  Подключился к сети через {args.join}, известно узлов: "
                  f"{len(service.gossip.known_peers)}")

        print("\nУзел работает. Ctrl+C для остановки.")
        try:
            while True:
                await asyncio.sleep(1)
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass
        finally:
            await service.stop()
            print("\nУзел остановлен.")

    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        pass


def cmd_status(_args: argparse.Namespace) -> None:
    ledger = IncentiveLedger(storage_path=str(CONFIG_PATH.parent / "ledger.json"))
    board = ledger.leaderboard()
    if not board:
        print("Пока нет данных о вкладе узлов в этой сети.")
        return
    print("Топ узлов по вкладу:")
    for line in board:
        print(" ", line)


def main() -> None:
    parser = argparse.ArgumentParser(prog="meshmind", description="Узел распределённой AI-сети")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("setup", help="Интерактивная настройка узла").set_defaults(func=cmd_setup)

    start_parser = sub.add_parser("start", help="Запуск узла")
    start_parser.add_argument(
        "--join", metavar="HOST:PORT", default=None,
        help="Подключиться к существующей сети через известный узел (gossip bootstrap)",
    )
    start_parser.add_argument(
        "--no-dashboard", action="store_true",
        help="Не поднимать веб-дашборд мониторинга",
    )
    start_parser.set_defaults(func=cmd_start)

    sub.add_parser("status", help="Статус сети и рейтинг узлов").set_defaults(func=cmd_status)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
