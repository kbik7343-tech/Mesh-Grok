"""
orchestrator.py — связывает определение сложности (complexity.py) с
реальным вызовом локальной или облачной модели.

ЧЕСТНО О ГРАНИЦАХ ТЕСТИРОВАНИЯ:
- Логика маршрутизации (какой путь выбрать) — протестирована ниже,
  полностью, на реальных примерах промптов.
- Вызов локальной модели (LocalModelRunner) — здесь интерфейс и
  заглушка; реальная реализация на твоей стороне подключит
  llama.cpp (через gguf-квантованную Gemma/Phi-3) или
  transformers — оба варианта требуют скачивания весов, что здесь
  невозможно без интернета.
- Вызов облачной модели — интерфейс под Anthropic API; тоже не
  вызывался реально (нет сетевого доступа из этой среды), но
  структура стандартная и должна работать как есть.
"""

from __future__ import annotations

import socket
from dataclasses import dataclass
from typing import Callable, Protocol

from .complexity import RouteTarget, decide_route


class ModelRunner(Protocol):
    """Общий интерфейс и для локальной, и для облачной модели."""

    def generate(self, prompt: str) -> str: ...


@dataclass
class StubLocalModel:
    """
    ЗАГЛУШКА для тестирования логики без реальных весов модели.
    Реальная замена — LlamaCppRunner или HFLocalRunner (см. ниже
    комментарий с псевдокодом интеграции).
    """

    def generate(self, prompt: str) -> str:
        return f"[локальный ответ, {len(prompt.split())} слов входа]"


@dataclass
class StubCloudModel:
    """ЗАГЛУШКА для тестирования — реальная версия стучится в облачный API."""

    def generate(self, prompt: str) -> str:
        return f"[облачный ответ, {len(prompt.split())} слов входа]"


def check_internet(host: str = "8.8.8.8", port: int = 53, timeout: float = 1.5) -> bool:
    """
    Реальная проверка наличия интернета (а не заглушка) — пытается
    открыть TCP-сокет до публичного DNS Google. Это стандартный лёгкий
    способ проверки связности без зависимости от конкретного сайта.
    """
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        return True
    except OSError:
        return False


class HybridOrchestrator:
    def __init__(
        self,
        local_model: ModelRunner,
        cloud_model: ModelRunner,
        is_online_check: Callable[[], bool] = check_internet,
    ) -> None:
        self._local = local_model
        self._cloud = cloud_model
        self._is_online_check = is_online_check
        self.last_decision = None  # для отладки/логирования UI

    def answer(self, prompt: str) -> str:
        is_online = self._is_online_check()
        decision = decide_route(prompt, is_online=is_online)
        self.last_decision = decision

        runner = self._local if decision.target == RouteTarget.LOCAL else self._cloud
        return runner.generate(prompt)


# --- Псевдокод реальной интеграции (не выполнялось, для справки) ---
#
# class LlamaCppRunner:
#     def __init__(self, model_path: str):
#         from llama_cpp import Llama  # pip install llama-cpp-python
#         self._llm = Llama(model_path=model_path, n_ctx=2048)
#
#     def generate(self, prompt: str) -> str:
#         result = self._llm(prompt, max_tokens=256)
#         return result["choices"][0]["text"]
#
# class AnthropicCloudRunner:
#     def __init__(self, api_key: str):
#         import anthropic
#         self._client = anthropic.Anthropic(api_key=api_key)
#
#     def generate(self, prompt: str) -> str:
#         response = self._client.messages.create(
#             model="claude-sonnet-4-6",
#             max_tokens=1000,
#             messages=[{"role": "user", "content": prompt}],
#         )
#         return response.content[0].text
