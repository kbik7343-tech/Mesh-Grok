"""
speculative.py — speculative decoding через гибридную сеть: маленькая
ЛОКАЛЬНАЯ модель быстро "предлагает" несколько токенов вперёд, а
большая модель (облако/распределённая сеть) проверяет их ОДНИМ
проходом вместо последовательной генерации токен-за-токеном.

Почему это ускоряет: обычная генерация — n последовательных вызовов
большой модели для n токенов (с сетевой задержкой на каждый — особенно
больно в распределённой сети типа нашей). Spec decoding — 1 вызов
маленькой модели (быстро, локально) + 1 проверочный вызов большой
модели на пакет из k токенов сразу (параллельно, не последовательно).
Если черновик совпал с тем, что сгенерировала бы большая модель — эти
токены приняты "бесплатно". Если нет — откатываемся к первому
расхождению и большая модель досчитывает сама с этого места.

Это РЕАЛЬНАЯ техника (используется в продакшене многими AI-компаниями
для ускорения инференса), но обычно в рамках одной модели/сервера.
Применение её через СЕТЬ (локальный черновик -> распределённая
верификация) — расширение, которое годится именно для нашего
гибридного сценария, уменьшая число сетевых round-trip'ов.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence


@dataclass
class SpeculationResult:
    accepted_tokens: list[str]
    rejected_at: int | None   # индекс первого расхождения, None если всё принято
    num_drafted: int
    num_accepted: int
    network_calls_saved: int  # сколько последовательных сетевых вызовов не понадобилось


DraftFn = Callable[[list[str], int], list[str]]       # (контекст, k) -> k черновых токенов
VerifyFn = Callable[[list[str], list[str]], list[bool]]  # (контекст, черновик) -> совпадение по каждому токену


def speculative_generate(
    context: list[str],
    draft_fn: DraftFn,
    verify_fn: VerifyFn,
    num_speculative_tokens: int = 4,
) -> SpeculationResult:
    """
    Один раунд speculative decoding. draft_fn — вызов локальной модели
    (быстро, без сети). verify_fn — ОДИН сетевой вызов к
    большой/распределённой модели, который проверяет весь пакет разом
    и возвращает, какие токены из черновика совпадают с тем, что
    сгенерировала бы сама большая модель на каждой позиции.

    Контракт verify_fn: как только встретилось первое несовпадение,
    все токены ПОСЛЕ него в черновике недействительны (контекст для
    них был бы другим) — поэтому принимаем только префикс до первого False.
    """
    draft = draft_fn(context, num_speculative_tokens)
    if not draft:
        return SpeculationResult([], None, 0, 0, 0)

    matches = verify_fn(context, draft)
    if len(matches) != len(draft):
        raise ValueError("verify_fn должна вернуть ровно по одному результату на токен черновика")

    accepted: list[str] = []
    rejected_at: int | None = None
    for i, (token, is_match) in enumerate(zip(draft, matches)):
        if is_match:
            accepted.append(token)
        else:
            rejected_at = i
            break

    # Без speculative decoding потребовалось бы len(accepted)+1 отдельных
    # последовательных сетевых вызовов (по одному на токен + 1 на
    # отвергнутый/следующий); с speculative decoding — всего 1 вызов verify_fn.
    network_calls_saved = max(0, len(accepted) + (1 if rejected_at is not None else 0) - 1)

    return SpeculationResult(
        accepted_tokens=accepted,
        rejected_at=rejected_at,
        num_drafted=len(draft),
        num_accepted=len(accepted),
        network_calls_saved=network_calls_saved,
    )


def run_full_generation(
    initial_context: list[str],
    draft_fn: DraftFn,
    verify_fn: VerifyFn,
    fallback_fn: Callable[[list[str]], str],
    max_tokens: int,
    num_speculative_tokens: int = 4,
) -> tuple[list[str], int]:
    """
    Полный цикл генерации до max_tokens новых токенов, раунд за раундом
    speculative_generate. fallback_fn — вызывается на токене, где
    черновик разошёлся (нужно всё равно получить ПРАВИЛЬНЫЙ токен от
    большой модели для этой позиции, иначе просто отбросить расхождение
    и потерять токен).

    Возвращает (сгенерированные_токены, всего_сэкономленных_сетевых_вызовов).
    """
    context = list(initial_context)
    generated: list[str] = []
    total_saved = 0

    while len(generated) < max_tokens:
        remaining = max_tokens - len(generated)
        k = min(num_speculative_tokens, remaining)

        result = speculative_generate(context, draft_fn, verify_fn, num_speculative_tokens=k)
        generated.extend(result.accepted_tokens)
        context.extend(result.accepted_tokens)
        total_saved += result.network_calls_saved

        if result.rejected_at is not None:
            # Докидываем правильный токен на месте расхождения одним вызовом
            correct_token = fallback_fn(context)
            generated.append(correct_token)
            context.append(correct_token)
        elif result.num_drafted == 0:
            break  # черновик пуст — модель решила, что генерация окончена

    return generated[:max_tokens], total_saved
