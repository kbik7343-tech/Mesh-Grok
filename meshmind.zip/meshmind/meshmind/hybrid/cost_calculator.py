"""
cost_calculator.py — считает реальную экономию от гибридного подхода
(локальная модель + облако) против "всё в облако".

Цены взяты по актуальному прайсу Anthropic API (проверено поиском):
Sonnet ~$3/$15 за млн токенов вход/выход, Haiku ~$1/$5.
Локальная модель на устройстве пользователя стоит $0 по API
(электричество/батарея не считаем — это расход пользователя, не твой).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CloudPricing:
    name: str
    input_per_mtok: float   # $ за миллион входных токенов
    output_per_mtok: float  # $ за миллион выходных токенов


SONNET = CloudPricing("Sonnet", input_per_mtok=3.0, output_per_mtok=15.0)
HAIKU = CloudPricing("Haiku", input_per_mtok=1.0, output_per_mtok=5.0)


@dataclass
class UsageScenario:
    name: str
    daily_active_users: int
    queries_per_user_per_day: float
    avg_input_tokens: int
    avg_output_tokens: int
    local_share: float  # доля запросов, уходящих локально (0.0-1.0)
    cloud_pricing: CloudPricing


def monthly_queries(scenario: UsageScenario) -> float:
    return scenario.daily_active_users * scenario.queries_per_user_per_day * 30


def cost_all_cloud(scenario: UsageScenario) -> float:
    """Сколько стоило бы, если ВСЕ запросы шли в облако (базовый сценарий для сравнения)."""
    queries = monthly_queries(scenario)
    input_cost = queries * scenario.avg_input_tokens / 1_000_000 * scenario.cloud_pricing.input_per_mtok
    output_cost = queries * scenario.avg_output_tokens / 1_000_000 * scenario.cloud_pricing.output_per_mtok
    return input_cost + output_cost


def cost_hybrid(scenario: UsageScenario) -> float:
    """Стоимость при гибридной схеме — локальная доля не стоит тебе ничего по API."""
    cloud_share = 1.0 - scenario.local_share
    queries = monthly_queries(scenario) * cloud_share
    input_cost = queries * scenario.avg_input_tokens / 1_000_000 * scenario.cloud_pricing.input_per_mtok
    output_cost = queries * scenario.avg_output_tokens / 1_000_000 * scenario.cloud_pricing.output_per_mtok
    return input_cost + output_cost


def report(scenario: UsageScenario) -> str:
    all_cloud = cost_all_cloud(scenario)
    hybrid = cost_hybrid(scenario)
    savings = all_cloud - hybrid
    savings_pct = (savings / all_cloud * 100) if all_cloud else 0

    lines = [
        f"=== {scenario.name} ===",
        f"Пользователей/день: {scenario.daily_active_users:,} · "
        f"запросов/день на юзера: {scenario.queries_per_user_per_day} · "
        f"модель облака: {scenario.cloud_pricing.name}",
        f"Доля локальных запросов: {scenario.local_share:.0%}",
        f"Запросов в месяц всего: {monthly_queries(scenario):,.0f}",
        "",
        f"Все запросы в облако:     ${all_cloud:>10,.2f}/мес",
        f"Гибрид (локально+облако): ${hybrid:>10,.2f}/мес",
        f"Экономия:                 ${savings:>10,.2f}/мес ({savings_pct:.0f}%)",
        f"Экономия в год:            ${savings * 12:>10,.2f}",
    ]
    return "\n".join(lines)
