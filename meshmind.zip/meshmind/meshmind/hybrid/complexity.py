"""
complexity.py — эвристика "простой запрос -> локальная модель 1-3B,
сложный -> облачная большая модель". Это ключевая логика гибрида:
от её точности зависит и приватность (меньше данных в облако), и
качество ответов (сложные задачи не должны уходить на слабую
локальную модель).

Специально без ML-классификатора — такая модель сама требует
обучения и датасета разметки "сложно/просто", что отдельная задача.
Здесь прозрачные, объяснимые правила, которые можно обсуждать и
настраивать руками, разумный компромисс для MVP.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum


class RouteTarget(Enum):
    LOCAL = "local"
    CLOUD = "cloud"


@dataclass
class ComplexitySignals:
    """Отдельные сигналы сложности — для прозрачности и отладки решений."""

    token_count: int
    has_code_block: bool
    has_multi_step_markers: bool  # "во-первых", "затем", нумерованные списки в запросе
    requires_recent_knowledge: bool  # упоминания "сейчас", "последние новости", даты
    question_depth: int  # количество вложенных вопросов/подзадач


# Ключевые слова-маркеры многошаговости и потребности в актуальных знаниях.
# Это не NLP, а простой lexicon — осознанно просто и предсказуемо для MVP.
_MULTISTEP_MARKERS = (
    "во-первых", "затем", "после этого", "шаг 1", "шаг 2", "сначала",
    "step 1", "step 2", "first,", "then,", "after that",
)
_RECENCY_MARKERS = (
    "сейчас", "последние новости", "текущий", "актуальн", "в этом году",
    "today", "latest", "current", "right now",
)
_CODE_BLOCK_PATTERN = re.compile(r"```|def |class |function |SELECT |import ")


def extract_signals(prompt: str) -> ComplexitySignals:
    lowered = prompt.lower()
    return ComplexitySignals(
        token_count=len(prompt.split()),
        has_code_block=bool(_CODE_BLOCK_PATTERN.search(prompt)),
        has_multi_step_markers=any(m in lowered for m in _MULTISTEP_MARKERS),
        requires_recent_knowledge=any(m in lowered for m in _RECENCY_MARKERS),
        question_depth=prompt.count("?"),
    )


@dataclass
class RoutingDecision:
    target: RouteTarget
    reason: str
    signals: ComplexitySignals


def decide_route(
    prompt: str,
    is_online: bool,
    token_threshold: int = 40,
    force_local_offline: bool = True,
) -> RoutingDecision:
    """
    Главная функция решения. Правила применяются по приоритету:
    1. Офлайн -> всегда локально (единственный доступный вариант).
    2. Короткий простой запрос без маркеров сложности -> локально.
    3. Всё остальное (длинный, код, многошаговый, актуальные знания) -> облако.
    """
    signals = extract_signals(prompt)

    if not is_online and force_local_offline:
        return RoutingDecision(RouteTarget.LOCAL, "устройство офлайн — облако недоступно", signals)

    complexity_flags = [
        signals.token_count > token_threshold,
        signals.has_code_block,
        signals.has_multi_step_markers,
        signals.requires_recent_knowledge,
        signals.question_depth >= 2,
    ]

    if any(complexity_flags):
        reasons = []
        if signals.token_count > token_threshold:
            reasons.append(f"длинный запрос ({signals.token_count} слов)")
        if signals.has_code_block:
            reasons.append("содержит код")
        if signals.has_multi_step_markers:
            reasons.append("многошаговая задача")
        if signals.requires_recent_knowledge:
            reasons.append("требует актуальных знаний")
        if signals.question_depth >= 2:
            reasons.append("несколько вложенных вопросов")
        return RoutingDecision(RouteTarget.CLOUD, " + ".join(reasons), signals)

    return RoutingDecision(RouteTarget.LOCAL, "короткий простой запрос", signals)
