"""
federated.py — федеративное дообучение: узлы считают обновления весов
на СВОИХ локальных данных и присылают координатору только эти
обновления (числа), а не сами данные пользователей — координатор
никогда не видит исходные тексты/примеры, только усреднённую дельту.

Реализован FedAvg (McMahan et al., 2017) — стандартный базовый
алгоритм федеративного обучения: усреднение весов узлов, взвешенное
по размеру локальной выборки каждого узла (у кого больше данных —
тот весомее влияет на общий результат).

ЧЕСТНО О ГРАНИЦАХ: здесь представлены веса как обычные списки float
(вектора), а не torch.Tensor с реальными градиентами настоящей нейросети
— сам алгоритм усреднения идентичен что для чисел, что для тензоров
(torch.Tensor поддерживает те же арифметические операции), но подключение
к реальному обучению (вычисление градиентов через backward pass) требует
torch и реальных данных, которых здесь нет. Это дополняется
privacy.py (можно добавить шум к обновлениям перед отправкой — та же
техника дифференциальной приватности, что уже реализована там) и
incentives.py (узлы с большим и качественным вкладом получают больше очков).
"""

from __future__ import annotations

from dataclasses import dataclass


Vector = list[float]


@dataclass
class ClientUpdate:
    """Один узел прислал обновление весов после локального дообучения."""

    node_id: str
    weight_delta: Vector    # разница между локально обученными весами и исходными глобальными
    num_local_samples: int  # размер локальной выборки — вес узла при усреднении


def _validate_same_dimension(updates: list[ClientUpdate]) -> int:
    dims = {len(u.weight_delta) for u in updates}
    if len(dims) > 1:
        raise ValueError(f"Обновления узлов имеют разную размерность: {dims}")
    return dims.pop()


def federated_average(updates: list[ClientUpdate]) -> Vector:
    """
    Базовый FedAvg: взвешенное по num_local_samples усреднение обновлений.
    Узел с 1000 примеров влияет на итог в 10 раз сильнее узла с 100 —
    это соответствует интуиции "больше данных = более надёжная оценка".
    """
    if not updates:
        raise ValueError("Нет обновлений для усреднения")

    dim = _validate_same_dimension(updates)
    total_samples = sum(u.num_local_samples for u in updates)
    if total_samples == 0:
        raise ValueError("Суммарный размер выборки равен нулю — нечего усреднять")

    averaged = [0.0] * dim
    for update in updates:
        weight = update.num_local_samples / total_samples
        for i, delta in enumerate(update.weight_delta):
            averaged[i] += delta * weight

    return averaged


def apply_update(global_weights: Vector, delta: Vector, learning_rate: float = 1.0) -> Vector:
    """Применяет усреднённую дельту к текущим глобальным весам."""
    if len(global_weights) != len(delta):
        raise ValueError("Размерность весов и дельты не совпадает")
    return [w + learning_rate * d for w, d in zip(global_weights, delta)]


def filter_outlier_updates(
    updates: list[ClientUpdate],
    max_delta_norm: float,
) -> tuple[list[ClientUpdate], list[str]]:
    """
    Защита от атаки отравления (poisoning attack): недобросовестный
    узел может прислать аномально большое обновление, чтобы сильно
    исказить общую модель в свою пользу. Отсекаем обновления с нормой
    (длиной вектора) больше max_delta_norm — честные локальные
    дообучения обычно дают небольшие, инкрементальные изменения весов.

    Возвращает (отфильтрованные_обновления, id_отклонённых_узлов).
    """
    kept, rejected = [], []
    for update in updates:
        norm = sum(d ** 2 for d in update.weight_delta) ** 0.5
        if norm <= max_delta_norm:
            kept.append(update)
        else:
            rejected.append(update.node_id)
    return kept, rejected
