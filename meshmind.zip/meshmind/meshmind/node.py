"""
node.py — описание узла сети и самодиагностика возможностей устройства.

Каждый узел (ноутбук/сервер добровольца) перед подключением к сети
измеряет свои характеристики и публикует их в реестр (router.py читает
эти данные для маршрутизации, incentives.py — для расчёта вклада).
"""

from __future__ import annotations

import platform
import socket
import time
import uuid
from dataclasses import dataclass, field


def _detect_ram_gb() -> float:
    """Грубая оценка объёма RAM без внешних зависимостей (psutil опционален)."""
    try:
        import psutil  # type: ignore

        return round(psutil.virtual_memory().total / (1024 ** 3), 1)
    except ImportError:
        # Фолбэк для Linux без psutil
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        kb = int(line.split()[1])
                        return round(kb / (1024 ** 2), 1)
        except OSError:
            pass
    return 0.0


def _detect_gpu() -> tuple[bool, str]:
    """Проверяет доступность CUDA-совместимого GPU через torch, если он есть."""
    try:
        import torch  # type: ignore

        if torch.cuda.is_available():
            return True, torch.cuda.get_device_name(0)
    except ImportError:
        pass
    return False, "none"


@dataclass
class NodeCapabilities:
    """Снимок возможностей устройства на момент подключения к сети."""

    ram_gb: float
    has_gpu: bool
    gpu_name: str
    os_name: str
    cpu_arch: str

    @classmethod
    def probe(cls) -> "NodeCapabilities":
        has_gpu, gpu_name = _detect_gpu()
        return cls(
            ram_gb=_detect_ram_gb(),
            has_gpu=has_gpu,
            gpu_name=gpu_name,
            os_name=platform.system(),
            cpu_arch=platform.machine(),
        )

    def estimated_capacity_score(self) -> float:
        """
        Условная оценка "сколько блоков модели узел может держать".
        GPU считается значительно ценнее CPU-only узла.
        """
        base = self.ram_gb / 4.0  # ~4 ГБ на условный блок в FP16
        if self.has_gpu:
            base *= 3.0
        return round(max(base, 0.1), 2)


@dataclass
class NodeInfo:
    """Публичная запись об узле, которую видят остальные участники сети."""

    node_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    hostname: str = field(default_factory=socket.gethostname)
    joined_at: float = field(default_factory=time.time)
    capabilities: NodeCapabilities = field(default_factory=NodeCapabilities.probe)
    public_key_fingerprint: str = ""  # заполняется privacy.py при генерации ключей

    def summary(self) -> str:
        caps = self.capabilities
        gpu = f"GPU: {caps.gpu_name}" if caps.has_gpu else "GPU: нет"
        return (
            f"[{self.node_id}] {self.hostname} · "
            f"RAM: {caps.ram_gb} ГБ · {gpu} · "
            f"ёмкость: {caps.estimated_capacity_score()} блоков"
        )
