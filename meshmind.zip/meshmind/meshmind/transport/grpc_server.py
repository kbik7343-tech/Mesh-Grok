"""
grpc_server.py — gRPC-сервер узла сети.

НЕ ЗАПУСКАЛОСЬ В ЭТОЙ СРЕДЕ (нет интернета, не поставить grpcio).
Код написан по официальному API grpc.aio и должен работать как есть
после установки зависимостей и генерации meshmind_pb2*.py из .proto —
но перед продакшеном проверь у себя: `python -m meshmind.transport.grpc_server`.

Требует:
    pip install grpcio grpcio-tools
    python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. meshmind.proto
"""

from __future__ import annotations

import asyncio
import logging
import time
from concurrent import futures

import grpc

from . import meshmind_pb2, meshmind_pb2_grpc  # сгенерированы из .proto, см. docstring выше
from ..privacy import HopEncryption
from ..router import RoutingTable

logger = logging.getLogger("meshmind.server")


class MeshNodeServicer(meshmind_pb2_grpc.MeshNodeServicer):
    """
    Реализация узла. `block_runner` — функция, выполняющая реальный
    форвард-проход через блоки модели (подключается отдельно, см.
    hf_integration.py — она не знает про gRPC, только про тензоры).
    """

    def __init__(
        self,
        node_id: str,
        block_runner,  # Callable[[bytes, int, int], bytes]
        hop_key: bytes | None = None,
    ) -> None:
        self.node_id = node_id
        self._block_runner = block_runner
        self._hop_encryption = HopEncryption(session_key=hop_key) if hop_key else None

    async def Forward(
        self, request: meshmind_pb2.ForwardRequest, context: grpc.aio.ServicerContext
    ) -> meshmind_pb2.ForwardResponse:
        start = time.time()
        try:
            payload = request.activations
            if self._hop_encryption and request.encrypted_payload:
                payload = self._hop_encryption.decrypt(request.encrypted_payload)

            # Реальная вычислительная работа — делегируется наружу,
            # сервер транспорта не должен знать детали модели.
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._block_runner, payload, request.block_id_start, request.block_id_end
            )

            response = meshmind_pb2.ForwardResponse(
                request_id=request.request_id,
                ok=True,
                server_timestamp_ms=int(time.time() * 1000),
            )
            if self._hop_encryption:
                response.encrypted_payload = self._hop_encryption.encrypt(result)
            else:
                response.activations = result
            return response

        except Exception as exc:  # noqa: BLE001 — узел должен сообщить об ошибке, не падать
            logger.exception("Ошибка форварда для %s", request.request_id)
            return meshmind_pb2.ForwardResponse(
                request_id=request.request_id,
                ok=False,
                error_message=str(exc),
                server_timestamp_ms=int(time.time() * 1000),
            )
        finally:
            logger.debug("Forward %s обработан за %.1f мс", request.request_id, (time.time() - start) * 1000)

    async def Announce(
        self, request: meshmind_pb2.NodeAnnouncement, context: grpc.aio.ServicerContext
    ) -> meshmind_pb2.AnnouncementAck:
        logger.info(
            "Узел %s объявил блоки %s (RAM=%.1fГБ, GPU=%s)",
            request.node_id, list(request.hosted_blocks), request.ram_gb, request.has_gpu,
        )
        return meshmind_pb2.AnnouncementAck(accepted=True, message="ok")

    async def HealthCheck(
        self, request: meshmind_pb2.Ping, context: grpc.aio.ServicerContext
    ) -> meshmind_pb2.Pong:
        return meshmind_pb2.Pong(node_id=self.node_id, server_timestamp_ms=int(time.time() * 1000))


async def serve(node_id: str, block_runner, port: int = 50051, hop_key: bytes | None = None) -> None:
    server = grpc.aio.server(futures.ThreadPoolExecutor(max_workers=8))
    meshmind_pb2_grpc.add_MeshNodeServicer_to_server(
        MeshNodeServicer(node_id, block_runner, hop_key), server
    )
    server.add_insecure_port(f"[::]:{port}")
    logger.info("Узел %s слушает порт %d", node_id, port)
    await server.start()
    await server.wait_for_termination()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    def dummy_block_runner(payload: bytes, start: int, end: int) -> bytes:
        # Заглушка — реальный раннер подключается из hf_integration.py
        return payload

    asyncio.run(serve(node_id="demo-node", block_runner=dummy_block_runner))
