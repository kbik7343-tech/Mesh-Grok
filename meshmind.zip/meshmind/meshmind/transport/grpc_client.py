"""
grpc_client.py — клиент, прогоняющий запрос через цепочку узлов (route),
построенную router.RoutingTable.build_route(). Тоже НЕ ЗАПУСКАЛОСЬ —
проверь вместе с grpc_server.py после установки зависимостей.
"""

from __future__ import annotations

import time
import uuid

import grpc

from . import meshmind_pb2, meshmind_pb2_grpc
from ..router import RoutingTable


class MeshClient:
    """
    node_addresses: node_id -> "host:port", обновляется из реестра узлов
    (например, по данным Announce, которые принял координатор).
    """

    def __init__(self, node_addresses: dict[str, str], router: RoutingTable) -> None:
        self._addresses = node_addresses
        self._router = router

    async def run_inference(self, input_tokens: bytes, num_blocks: int) -> bytes:
        route = self._router.build_route(num_blocks)
        request_id = str(uuid.uuid4())
        activations = input_tokens

        try:
            for hop_index, node_id in enumerate(route):
                address = self._addresses.get(node_id)
                if not address:
                    raise RuntimeError(f"Нет адреса для узла {node_id}")

                start = time.time()
                async with grpc.aio.insecure_channel(address) as channel:
                    stub = meshmind_pb2_grpc.MeshNodeStub(channel)
                    response = await stub.Forward(
                        meshmind_pb2.ForwardRequest(
                            request_id=request_id,
                            block_id_start=hop_index,
                            block_id_end=hop_index,
                            activations=activations,
                            client_timestamp_ms=int(time.time() * 1000),
                        ),
                        timeout=10.0,
                    )
                latency_ms = (time.time() - start) * 1000

                if not response.ok:
                    self._router.report_result(node_id, ok=False)
                    raise RuntimeError(f"Узел {node_id} вернул ошибку: {response.error_message}")

                self._router.report_result(node_id, ok=True, latency_ms=latency_ms)
                activations = response.activations

            return activations
        finally:
            self._router.release_route(route)
