"""
gossip.py — узлы сами находят друг друга и распространяют информацию
о составе сети без центрального координатора, который знает всех.

Принцип (как в Bitcoin/BitTorrent/Cassandra): каждый узел периодически
выбирает несколько случайных известных ему соседей и обменивается с
ними списком всех узлов, которых знает. Информация расходится по сети
экспоненциально — после k раундов узел знает примерно min(N, 2^k)
других узлов. Это устойчиво к отказам (нет единой точки отказа,
в отличие от central RoutingTable из router.py) и самовосстанавливается
при появлении/уходе узлов.

ОТНОШЕНИЕ К router.py: RoutingTable — это ДАННЫЕ (кто владеет каким
блоком, с какой надёжностью), централизованные в одном процессе.
gossip.py — это МЕХАНИЗМ РАСПРОСТРАНЕНИЯ этих данных между независимыми
узлами, каждый из которых держит свою копию RoutingTable и обновляет
её по мере поступления сплетен. В проде они работают вместе: каждый
узел — это и RoutingTable (своя локальная копия знания о сети), и
GossipNode (протокол обмена этим знанием с соседями).
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from dataclasses import dataclass, field

logger = logging.getLogger("meshmind.gossip")


@dataclass
class PeerRecord:
    """То, что один узел знает об одном другом узле сети."""

    node_id: str
    host: str
    port: int
    last_heard_from: float = field(default_factory=time.time)

    def is_stale(self, timeout_s: float = 30.0) -> bool:
        return (time.time() - self.last_heard_from) > timeout_s


async def _read_line(reader: asyncio.StreamReader) -> dict:
    line = await reader.readline()
    return json.loads(line.decode("utf-8"))


async def _write_line(writer: asyncio.StreamWriter, message: dict) -> None:
    writer.write((json.dumps(message) + "\n").encode("utf-8"))
    await writer.drain()


class GossipNode:
    """
    Один узел, участвующий в gossip-протоколе. known_peers — локальное,
    постоянно обновляемое представление узла о составе сети; у разных
    узлов оно может временно отличаться (eventual consistency, не
    строгая — это осознанный компромисс gossip-протоколов ради
    отсутствия единой точки отказа).
    """

    def __init__(self, node_id: str, host: str = "127.0.0.1", port: int = 0,
                 fanout: int = 3, staleness_timeout_s: float = 30.0):
        self.node_id = node_id
        self.host = host
        self.port = port
        self.fanout = fanout  # сколько случайных соседей опрашивать за раунд
        self._staleness_timeout_s = staleness_timeout_s
        self.known_peers: dict[str, PeerRecord] = {}
        self._server: asyncio.AbstractServer | None = None
        self._gossip_task: asyncio.Task | None = None

    async def _handle_peer(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            their_view = await _read_line(reader)
            # Они прислали свой список известных пиров — мержим в свой
            self._merge_peer_list(their_view["peers"])

            # Отвечаем своим списком (включая только что обновлённый)
            await _write_line(writer, {"peers": self._serialize_known_peers()})
        finally:
            writer.close()
            await writer.wait_closed()

    def _serialize_known_peers(self) -> list[dict]:
        # Включаем и себя — иначе соседи никогда не узнают о нашем существовании
        self_record = {"node_id": self.node_id, "host": self.host, "port": self.port,
                        "last_heard_from": time.time()}
        others = [
            {"node_id": p.node_id, "host": p.host, "port": p.port, "last_heard_from": p.last_heard_from}
            for p in self.known_peers.values()
        ]
        return [self_record] + others

    def _merge_peer_list(self, peers: list[dict]) -> None:
        for p in peers:
            if p["node_id"] == self.node_id:
                continue  # не добавляем себя в свой же список
            existing = self.known_peers.get(p["node_id"])
            # Берём более свежую информацию — важно при конфликте версий
            if existing is None or p["last_heard_from"] > existing.last_heard_from:
                self.known_peers[p["node_id"]] = PeerRecord(
                    node_id=p["node_id"], host=p["host"], port=p["port"],
                    last_heard_from=p["last_heard_from"],
                )

    def prune_stale_peers(self) -> int:
        """Убирает узлы, от которых давно нет вестей (сами отвалились или недостижимы)."""
        stale = [nid for nid, p in self.known_peers.items() if p.is_stale(self._staleness_timeout_s)]
        for nid in stale:
            del self.known_peers[nid]
        return len(stale)

    async def start(self) -> int:
        self._server = await asyncio.start_server(self._handle_peer, self.host, self.port)
        self.port = self._server.sockets[0].getsockname()[1]
        return self.port

    async def stop(self) -> None:
        if self._gossip_task:
            self._gossip_task.cancel()
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    async def bootstrap(self, seed_host: str, seed_port: int) -> None:
        """Первое подключение к сети через один известный ('seed') узел."""
        await self._gossip_with(seed_host, seed_port)

    async def _gossip_with(self, host: str, port: int) -> bool:
        try:
            reader, writer = await asyncio.open_connection(host, port)
        except OSError:
            return False  # узел недоступен — не страшно, попробуем других в следующем раунде
        try:
            await _write_line(writer, {"peers": self._serialize_known_peers()})
            their_response = await _read_line(reader)
            self._merge_peer_list(their_response["peers"])
            return True
        finally:
            writer.close()
            await writer.wait_closed()

    async def gossip_round(self) -> int:
        """Один раунд: выбрать до fanout случайных известных пиров и обменяться с ними. Возвращает число успешных обменов."""
        self.prune_stale_peers()
        candidates = list(self.known_peers.values())
        if not candidates:
            return 0

        targets = random.sample(candidates, k=min(self.fanout, len(candidates)))
        successes = 0
        for peer in targets:
            if await self._gossip_with(peer.host, peer.port):
                successes += 1
        return successes

    async def run_periodic_gossip(self, interval_s: float = 1.0) -> None:
        """Фоновая задача — гоняет gossip_round каждые interval_s секунд, пока не остановят."""
        while True:
            await asyncio.sleep(interval_s)
            await self.gossip_round()
