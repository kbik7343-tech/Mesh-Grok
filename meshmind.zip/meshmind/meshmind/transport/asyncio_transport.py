"""
asyncio_transport.py — РАБОЧАЯ (протестированная) замена gRPC на
встроенных asyncio-сокетах. Используй это, пока не проверишь
grpc_server.py/grpc_client.py у себя с установленным grpcio.

Протокол предельно простой: длина сообщения (4 байта, big-endian) +
JSON с base64-полями. Для реального проекта лучше перейти на gRPC
(типизация, стриминг, зрелая экосистема) — это временный, но честно
работающий мост.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
import uuid
from dataclasses import dataclass
from typing import Awaitable, Callable

from ..ratelimit import RateLimiter
from ..router import RoutingTable

logger = logging.getLogger("meshmind.asyncio_transport")

BlockRunner = Callable[[bytes, int, int], bytes]


async def _read_message(reader: asyncio.StreamReader) -> dict:
    length_bytes = await reader.readexactly(4)
    length = int.from_bytes(length_bytes, "big")
    payload = await reader.readexactly(length)
    return json.loads(payload.decode("utf-8"))


async def _write_message(writer: asyncio.StreamWriter, message: dict) -> None:
    payload = json.dumps(message).encode("utf-8")
    writer.write(len(payload).to_bytes(4, "big"))
    writer.write(payload)
    await writer.drain()


@dataclass
class NodeServer:
    """Сервер одного узла — аналог MeshNodeServicer.Forward из gRPC-версии."""

    node_id: str
    block_runner: BlockRunner
    host: str = "127.0.0.1"
    port: int = 0  # 0 = ОС выберет свободный порт сама
    rate_limiter: RateLimiter | None = None  # None = без ограничений (как раньше)
    _server: asyncio.AbstractServer | None = None

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            request = await _read_message(reader)

            if self.rate_limiter is not None:
                # client_id явно из запроса (если клиент его передал) или адрес соединения —
                # так лимит работает даже для клиентов, не поддерживающих client_id.
                # По IP, не IP:port — у нас каждый запрос открывает новое
                # соединение с новым случайным локальным портом, так что
                # port в идентификаторе давал бы каждому запросу свой
                # собственный лимит и не ограничивал бы ничего.
                peer = writer.get_extra_info("peername")
                client_id = request.get("client_id") or (peer[0] if peer else "unknown")

                if not self.rate_limiter.allow(client_id):
                    retry_after = self.rate_limiter.retry_after(client_id)
                    await _write_message(writer, {
                        "request_id": request.get("request_id", "?"),
                        "ok": False,
                        "error_message": "rate_limited",
                        "retry_after_seconds": round(retry_after, 2),
                    })
                    return

            activations = base64.b64decode(request["activations_b64"])

            result = await asyncio.get_event_loop().run_in_executor(
                None, self.block_runner, activations,
                request["block_id_start"], request["block_id_end"],
            )

            await _write_message(writer, {
                "request_id": request["request_id"],
                "ok": True,
                "activations_b64": base64.b64encode(result).decode("ascii"),
                "server_timestamp_ms": int(time.time() * 1000),
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Ошибка обработки запроса на узле %s", self.node_id)
            try:
                await _write_message(writer, {
                    "request_id": request.get("request_id", "?") if "request" in dir() else "?",
                    "ok": False,
                    "error_message": str(exc),
                })
            except Exception:
                pass
        finally:
            writer.close()
            await writer.wait_closed()

    async def start(self) -> int:
        self._server = await asyncio.start_server(self._handle_client, self.host, self.port)
        actual_port = self._server.sockets[0].getsockname()[1]
        self.port = actual_port
        logger.info("Узел %s слушает %s:%d", self.node_id, self.host, actual_port)
        return actual_port

    async def stop(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()


class MeshClient:
    """Клиент — прогоняет запрос через маршрут, построенный router.py."""

    def __init__(self, node_addresses: dict[str, tuple[str, int]], router: RoutingTable) -> None:
        self._addresses = node_addresses
        self._router = router

    async def _forward_to_node(
        self, node_id: str, activations: bytes, hop_index: int, request_id: str
    ) -> bytes:
        host, port = self._addresses[node_id]
        start = time.time()

        reader, writer = await asyncio.open_connection(host, port)
        try:
            await _write_message(writer, {
                "request_id": request_id,
                "block_id_start": hop_index,
                "block_id_end": hop_index,
                "activations_b64": base64.b64encode(activations).decode("ascii"),
                "client_timestamp_ms": int(time.time() * 1000),
            })
            response = await _read_message(reader)
        finally:
            writer.close()
            await writer.wait_closed()

        latency_ms = (time.time() - start) * 1000

        if not response.get("ok"):
            self._router.report_result(node_id, ok=False)
            raise RuntimeError(f"Узел {node_id} вернул ошибку: {response.get('error_message')}")

        self._router.report_result(node_id, ok=True, latency_ms=latency_ms)
        return base64.b64decode(response["activations_b64"])

    async def run_inference(self, input_payload: bytes, num_blocks: int) -> bytes:
        route = self._router.build_route(num_blocks)
        request_id = str(uuid.uuid4())
        activations = input_payload
        try:
            for hop_index, node_id in enumerate(route):
                activations = await self._forward_to_node(node_id, activations, hop_index, request_id)
            return activations
        finally:
            self._router.release_route(route)
