"""
kv_cache.py — кэш ключей/значений внимания (KV-cache) на стороне узла,
чтобы при пошаговой генерации (токен за токеном) не пересчитывать
attention для всей предыдущей последовательности заново на каждом шаге.

Как это работает в реальном инференсе трансформера: при генерации
каждый новый токен требует attention со всеми предыдущими токенами.
Без кэша — пересчёт K/V-проекций для всей истории на каждом шаге,
O(n²) суммарно за генерацию. С кэшем — храним K/V с прошлых шагов,
считаем только для нового токена, O(n) суммарно. Именно так делает
Petals (RemoteSequenceManager + session-based past_key_values).

ВАЖНО О ГРАНИЦАХ: сам кэш здесь — чистая структура данных (хранение
opaque-байтов по ключу session_id+диапазон блоков, с TTL-вытеснением).
Она полностью тестируема без torch. А вот ПРИМЕНЕНИЕ кэша внутри
forward pass (передача past_key_values в сам вызов блока модели)
требует реального torch и глубокой интеграции с hf_integration.py —
это отмечено отдельно ниже как untested integration point.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CacheEntry:
    payload: bytes            # сериализованные past_key_values для этого диапазона блоков
    created_at: float = field(default_factory=time.time)
    last_used_at: float = field(default_factory=time.time)
    size_bytes: int = 0

    def touch(self) -> None:
        self.last_used_at = time.time()


class SessionKVCache:
    """
    Кэш одного узла. Ключ — (session_id, block_start, block_end), то
    есть кэш специфичен и для конкретного диалога/генерации, и для
    конкретного диапазона блоков, которые держит этот узел (на случай,
    если один узел временно обслуживает разные диапазоны).

    Вытеснение — по двум правилам одновременно: TTL (сессия давно не
    использовалась — например, пользователь ушёл) и лимит суммарного
    размера (узел с 8 ГБ RAM не может держать кэш на все сессии мира).
    """

    def __init__(self, ttl_seconds: float = 300.0, max_total_bytes: int = 512 * 1024 * 1024):
        self._store: dict[tuple[str, int, int], CacheEntry] = {}
        self._ttl_seconds = ttl_seconds
        self._max_total_bytes = max_total_bytes

    def _key(self, session_id: str, block_start: int, block_end: int) -> tuple[str, int, int]:
        return (session_id, block_start, block_end)

    def get(self, session_id: str, block_start: int, block_end: int) -> Optional[bytes]:
        self._evict_expired()
        key = self._key(session_id, block_start, block_end)
        entry = self._store.get(key)
        if entry is None:
            return None
        entry.touch()
        return entry.payload

    def put(self, session_id: str, block_start: int, block_end: int, payload: bytes) -> None:
        key = self._key(session_id, block_start, block_end)
        self._store[key] = CacheEntry(payload=payload, size_bytes=len(payload))
        self._evict_expired()
        self._evict_if_over_capacity()

    def invalidate_session(self, session_id: str) -> int:
        """Явная очистка (например, пользователь закрыл диалог) — возвращает число удалённых записей."""
        keys_to_remove = [k for k in self._store if k[0] == session_id]
        for key in keys_to_remove:
            del self._store[key]
        return len(keys_to_remove)

    def _evict_expired(self) -> None:
        now = time.time()
        expired = [
            key for key, entry in self._store.items()
            if (now - entry.last_used_at) > self._ttl_seconds
        ]
        for key in expired:
            del self._store[key]

    def _evict_if_over_capacity(self) -> None:
        """LRU-вытеснение, пока не впишемся в лимит по суммарному размеру."""
        total = sum(e.size_bytes for e in self._store.values())
        if total <= self._max_total_bytes:
            return

        # Сортируем по времени последнего использования — вытесняем самое старое первым
        by_lru = sorted(self._store.items(), key=lambda kv: kv[1].last_used_at)
        for key, entry in by_lru:
            if total <= self._max_total_bytes:
                break
            del self._store[key]
            total -= entry.size_bytes

    def stats(self) -> dict:
        total_bytes = sum(e.size_bytes for e in self._store.values())
        return {
            "entries": len(self._store),
            "total_bytes": total_bytes,
            "sessions": len({k[0] for k in self._store}),
        }


# --- Точка интеграции с реальным инференсом (НЕ протестировано, нужен torch) ---
#
# В hf_integration.py runner() должен был бы выглядеть так:
#
#   def runner(payload, block_start, block_end, session_id=None):
#       cached_kv_bytes = kv_cache.get(session_id, block_start, block_end) if session_id else None
#       past_key_values = torch.load(io.BytesIO(cached_kv_bytes)) if cached_kv_bytes else None
#
#       hidden_states, new_kv = block(
#           hidden_states, past_key_values=past_key_values, use_cache=True,
#       )[0:2]
#
#       if session_id:
#           buf = io.BytesIO(); torch.save(new_kv, buf)
#           kv_cache.put(session_id, block_start, block_end, buf.getvalue())
#
# Это не реализовано здесь, потому что без torch нельзя проверить, что
# past_key_values действительно имеют правильную форму для каждой
# архитектуры (у GPT-2 и Llama разный формат KV-тензоров).
