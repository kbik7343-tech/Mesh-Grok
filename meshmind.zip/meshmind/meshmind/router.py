"""
router.py — маршрутизация запроса через цепочку узлов.

Улучшение над базовым подходом Petals (который в первую очередь
минимизирует общее время прямого прохода): здесь маршрут выбирается
по комбинированному score = f(задержка, надёжность, текущая нагрузка),
а не только по скорости. Узел с идеальным пингом, но нестабильным
аптаймом, может проиграть чуть более медленному, но надёжному —
это снижает число обрывов пайплайна в середине генерации.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class NodeHealth:
    """
    Скользящая статистика по узлу. Обновляется после каждого
    запроса, прошедшего через этот узел (успех/провал, задержка).
    """

    node_id: str
    ewma_latency_ms: float = 200.0   # начальная оценка "по умолчанию"
    success_rate: float = 1.0        # экспоненциально сглаженная доля успехов
    active_requests: int = 0         # текущая нагрузка (для балансировки)
    last_seen: float = field(default_factory=time.time)
    _alpha: float = 0.3              # коэффициент сглаживания EWMA

    def record_success(self, latency_ms: float) -> None:
        self.ewma_latency_ms = self._alpha * latency_ms + (1 - self._alpha) * self.ewma_latency_ms
        self.success_rate = self._alpha * 1.0 + (1 - self._alpha) * self.success_rate
        self.last_seen = time.time()

    def record_failure(self) -> None:
        # Провал резко штрафует success_rate, но не обнуляет — единичный
        # сбой (например, обрыв Wi-Fi) не должен навсегда исключать узел.
        self.success_rate = self._alpha * 0.0 + (1 - self._alpha) * self.success_rate
        self.last_seen = time.time()

    def is_stale(self, timeout_s: float = 60.0) -> bool:
        return (time.time() - self.last_seen) > timeout_s

    def routing_score(self) -> float:
        """
        Меньше — лучше. Штрафуем за задержку, ненадёжность и перегрузку.
        Узел с success_rate ниже 0.5 практически исключается из маршрутов
        (штраф растёт нелинейно), не полагаясь только на среднюю задержку.
        """
        reliability_penalty = (1.0 - self.success_rate) ** 2 * 2000  # мс-эквивалент
        load_penalty = self.active_requests * 50  # мс за каждый параллельный запрос
        return self.ewma_latency_ms + reliability_penalty + load_penalty


class RoutingTable:
    """Реестр состояния узлов и выбор оптимальной цепочки для запроса."""

    def __init__(self) -> None:
        self._health: dict[str, NodeHealth] = {}
        # block_owners: какой узел держит какой блок модели (может быть несколько на блок)
        self._block_owners: dict[int, list[str]] = {}

    def register_block_owner(self, block_id: int, node_id: str) -> None:
        self._block_owners.setdefault(block_id, [])
        if node_id not in self._block_owners[block_id]:
            self._block_owners[block_id].append(node_id)
        self._health.setdefault(node_id, NodeHealth(node_id=node_id))

    def report_result(self, node_id: str, ok: bool, latency_ms: float = 0.0) -> None:
        health = self._health.setdefault(node_id, NodeHealth(node_id=node_id))
        if ok:
            health.record_success(latency_ms)
        else:
            health.record_failure()

    def _best_owner(self, block_id: int) -> Optional[str]:
        owners = self._block_owners.get(block_id, [])
        live_owners = [o for o in owners if not self._health.get(o, NodeHealth(o)).is_stale()]
        candidates = live_owners or owners
        if not candidates:
            return None
        return min(candidates, key=lambda n: self._health[n].routing_score())

    def build_route(self, num_blocks: int) -> list[str]:
        """
        Строит маршрут — по одному лучшему узлу на каждый блок модели.
        Возвращает список node_id по порядку прохождения. Если для
        какого-то блока нет живого владельца — исключение с указанием блока
        (в реальной системе здесь должен быть fallback/retry с backoff).
        """
        route: list[str] = []
        for block_id in range(num_blocks):
            owner = self._best_owner(block_id)
            if owner is None:
                raise RuntimeError(f"Нет доступного узла для блока #{block_id}")
            route.append(owner)
            self._health[owner].active_requests += 1
        return route

    def release_route(self, route: list[str]) -> None:
        """Снимает временную нагрузку после завершения запроса."""
        for node_id in route:
            if node_id in self._health:
                self._health[node_id].active_requests = max(
                    0, self._health[node_id].active_requests - 1
                )

    def snapshot(self) -> list[str]:
        return [
            f"{node_id}: score={h.routing_score():.0f} "
            f"(лат={h.ewma_latency_ms:.0f}мс, успех={h.success_rate:.0%}, "
            f"нагрузка={h.active_requests})"
            for node_id, h in sorted(self._health.items(), key=lambda kv: kv[1].routing_score())
        ]
