"""
service.py — единая точка входа, связывающая ВСЕ модули проекта в
одном запускаемом узле:

  - transport/asyncio_transport.py — приём запросов по сети
  - transport/gossip.py            — самообнаружение других узлов
  - transport/kv_cache.py          — ускорение повторной генерации
  - ratelimit.py                   — защита от спама запросов
  - router.py                      — выбор маршрутов (для клиентской стороны)
  - incentives.py                  — учёт вклада узла
  - dashboard/server.py            — веб-мониторинг (опционально)
  - verification/commit_verify.py  — честность вычислений

Это не новый функционал — это СБОРКА существующих, независимо
протестированных модулей в один процесс, запускаемый одной командой.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field

from .dashboard.server import DashboardServer
from .incentives import IncentiveLedger
from .node import NodeInfo
from .ratelimit import RateLimiter
from .router import RoutingTable
from .transport.asyncio_transport import NodeServer
from .transport.gossip import GossipNode
from .transport.kv_cache import SessionKVCache
from .verification.commit_verify import SpotCheckVerifier, commit

logger = logging.getLogger("meshmind.service")


@dataclass
class ServiceConfig:
    node_id: str | None = None
    host: str = "127.0.0.1"
    transport_port: int = 0
    gossip_port: int = 0
    dashboard_port: int | None = 8765  # None = без дашборда
    rate_limit_capacity: float = 20.0
    rate_limit_refill: float = 2.0
    spot_check_probability: float = 0.1
    enable_verification: bool = True


class MeshService:
    """
    Один узел сети meshmind со всеми подсистемами, поднятыми и
    связанными между собой. Это то, что реально запускает человек,
    который хочет предоставить свою машину сети (аналог "ноды" в
    Petals/Bittensor), а не разработчик, собирающий кусочки вручную.
    """

    def __init__(self, config: ServiceConfig | None = None):
        self.config = config or ServiceConfig()
        self.info = NodeInfo(node_id=self.config.node_id) if self.config.node_id else NodeInfo()
        self.config.node_id = self.info.node_id

        self.router = RoutingTable()
        self.ledger = IncentiveLedger(storage_path=None)
        self.rate_limiter = RateLimiter(
            capacity=self.config.rate_limit_capacity,
            refill_rate=self.config.rate_limit_refill,
        )
        self.kv_cache = SessionKVCache()
        self.verifier = SpotCheckVerifier(check_probability=self.config.spot_check_probability)

        self.gossip = GossipNode(
            node_id=self.info.node_id, host=self.config.host, port=self.config.gossip_port,
        )
        self._transport_server: NodeServer | None = None
        self._dashboard: DashboardServer | None = None
        self._gossip_task: asyncio.Task | None = None
        self._stats = {"requests_served": 0, "requests_rejected_rate_limit": 0, "started_at": None}

    def _block_runner(self, payload: bytes, block_start: int, block_end: int) -> bytes:
        """
        Демонстрационная функция обработки — в реальном развёртывании
        заменяется на hf_integration.block_runner_from_shard (нужен torch).
        Здесь — честная заглушка, но ПРОХОДЯЩАЯ через реальную верификацию.
        """
        self._stats["requests_served"] += 1
        result = payload + f"|{self.info.node_id}".encode()

        if self.config.enable_verification:
            nonce = f"{time.time()}".encode()
            self.verifier.record_commitment(
                request_id=f"req_{self._stats['requests_served']}",
                node_id=self.info.node_id,
                input_data=payload,
                output=result,
                nonce=nonce,
            )
        return result

    async def start(self) -> None:
        """Поднимает все сетевые подсистемы узла. После этого узел доступен снаружи."""
        self._transport_server = NodeServer(
            node_id=self.info.node_id,
            block_runner=self._block_runner,
            host=self.config.host,
            rate_limiter=self.rate_limiter,
        )
        transport_port = await self._transport_server.start()

        gossip_port = await self.gossip.start()
        self._gossip_task = asyncio.create_task(self.gossip.run_periodic_gossip(interval_s=5.0))

        if self.config.dashboard_port is not None:
            self._dashboard = DashboardServer(
                self.router, self.ledger, host=self.config.host, port=self.config.dashboard_port,
            )
            self._dashboard.start()

        self._stats["started_at"] = time.time()
        logger.info(
            "Узел %s запущен: transport=%d gossip=%d dashboard=%s",
            self.info.node_id, transport_port, gossip_port,
            self._dashboard.port if self._dashboard else "выкл",
        )

    async def join_network(self, seed_host: str, seed_port: int) -> None:
        """Подключается к существующей сети через один известный узел (gossip bootstrap)."""
        await self.gossip.bootstrap(seed_host, seed_port)
        for peer_id, peer in self.gossip.known_peers.items():
            self.router.register_block_owner(0, peer_id)  # упрощённо — в проде блоки известны из Announce

    async def stop(self) -> None:
        if self._gossip_task:
            self._gossip_task.cancel()
        if self._transport_server:
            await self._transport_server.stop()
        await self.gossip.stop()
        if self._dashboard:
            self._dashboard.stop()

    @property
    def transport_port(self) -> int:
        return self._transport_server.port if self._transport_server else -1

    @property
    def gossip_port(self) -> int:
        return self.gossip.port

    @property
    def dashboard_url(self) -> str | None:
        if self._dashboard:
            return f"http://{self.config.host}:{self._dashboard.port}"
        return None

    def status(self) -> dict:
        return {
            "node_id": self.info.node_id,
            "uptime_seconds": (time.time() - self._stats["started_at"]) if self._stats["started_at"] else 0,
            "transport_port": self.transport_port,
            "gossip_port": self.gossip_port,
            "known_peers": list(self.gossip.known_peers.keys()),
            "dashboard_url": self.dashboard_url,
            "requests_served": self._stats["requests_served"],
            "requests_rejected_rate_limit": self._stats["requests_rejected_rate_limit"],
            "incentive_points": self.ledger._get(self.info.node_id).points,
            "capacity_score": self.info.capabilities.estimated_capacity_score(),
        }
