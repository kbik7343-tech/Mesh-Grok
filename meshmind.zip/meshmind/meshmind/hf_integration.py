"""
hf_integration.py — загрузка модели через HuggingFace Transformers и
разбиение её на блоки (слои трансформера) для распределения по узлам.

НЕ ЗАПУСКАЛОСЬ В ЭТОЙ СРЕДЕ (нет интернета — не скачать веса модели,
не поставить torch/transformers). Код написан по официальному API
и должен работать как есть, но перед продакшеном проверь у себя:

    pip install transformers torch accelerate
    python -c "from meshmind.hf_integration import load_and_split; \
               load_and_split('sshleifer/tiny-gpt2', num_shards=2)"
    # 'sshleifer/tiny-gpt2' — крошечная тестовая модель (~2 МБ), удобна
    # для проверки пайплайна перед работой с настоящими большими моделями.

Идея разбиения та же, что у Petals: современные LLM — это стопка
одинаковых по структуре блоков-трансформеров (attention + MLP), и их
можно физически разрезать на подряд идущие диапазоны, раздать разным
узлам, а на границах блоков передавать только hidden_states (тензор
активаций), а не всю модель целиком.
"""

from __future__ import annotations

import io
from dataclasses import dataclass


@dataclass
class ModelShard:
    """
    Один "кусок" модели — диапазон блоков трансформера [start, end),
    который физически хранится на конкретном узле. Соответствует
    полям block_id_start/block_id_end в transport/meshmind.proto.
    """

    shard_index: int
    block_start: int
    block_end: int  # исключительно, как range()
    num_params: int
    state_dict_bytes: bytes  # сериализованные веса этого диапазона блоков


def load_and_split(model_name: str, num_shards: int, dtype: str = "float16"):
    """
    Загружает модель с HuggingFace Hub и возвращает список ModelShard —
    по одному на каждый узел-владелец. Веса реально выгружаются из
    общей модели, а не просто "помечаются" — после разбиения из памяти
    можно освободить исходную полную модель.
    """
    import torch
    from transformers import AutoConfig, AutoModelForCausalLM

    config = AutoConfig.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name, torch_dtype=getattr(torch, dtype)
    )

    # Унифицированный доступ к списку блоков — у разных архитектур
    # (GPT-2, Llama, Mistral, Bloom) путь к ним называется по-разному.
    transformer_blocks = _locate_transformer_blocks(model)
    total_blocks = len(transformer_blocks)

    if num_shards > total_blocks:
        raise ValueError(
            f"Запрошено {num_shards} шардов, но в модели только {total_blocks} блоков"
        )

    shards: list[ModelShard] = []
    blocks_per_shard = total_blocks // num_shards
    remainder = total_blocks % num_shards
    cursor = 0

    for shard_index in range(num_shards):
        # Остаток блоков равномерно распределяем по первым шардам,
        # чтобы не получить один сильно перегруженный "хвостовой" шард.
        size = blocks_per_shard + (1 if shard_index < remainder else 0)
        block_start, block_end = cursor, cursor + size
        cursor = block_end

        shard_state = {}
        num_params = 0
        for local_idx, block_idx in enumerate(range(block_start, block_end)):
            block = transformer_blocks[block_idx]
            for param_name, param in block.state_dict().items():
                key = f"block_{local_idx}.{param_name}"
                shard_state[key] = param
                num_params += param.numel()

        buffer = io.BytesIO()
        torch.save(shard_state, buffer)

        shards.append(
            ModelShard(
                shard_index=shard_index,
                block_start=block_start,
                block_end=block_end,
                num_params=num_params,
                state_dict_bytes=buffer.getvalue(),
            )
        )

    return shards, config


def _locate_transformer_blocks(model):
    """
    Разные архитектуры по-разному называют список блоков:
      - GPT-2/GPT-Neo: model.transformer.h
      - Llama/Mistral:  model.model.layers
      - BLOOM:          model.transformer.h
    Эта функция ищет первый подходящий атрибут вместо жёсткой привязки
    к одной архитектуре — так разбиение работает для большинства
    decoder-only моделей на Hub без переписывания кода под каждую.
    """
    candidate_paths = [
        ("transformer", "h"),       # GPT-2, BLOOM, GPT-Neo
        ("model", "layers"),        # Llama, Mistral, Qwen
        ("gpt_neox", "layers"),     # GPT-NeoX
    ]
    for outer, inner in candidate_paths:
        if hasattr(model, outer) and hasattr(getattr(model, outer), inner):
            return getattr(getattr(model, outer), inner)

    raise ValueError(
        f"Не удалось найти список блоков трансформера в архитектуре "
        f"{type(model).__name__} — добавь путь в candidate_paths вручную."
    )


def _build_block_modules(config, num_blocks: int):
    """
    Создаёт num_blocks пустых (неинициализированных весами) модулей
    нужного архитектурного класса — архитектура определяется по
    config.model_type. Веса загружаются отдельно из shard.state_dict_bytes.

    ОГРАНИЧЕНИЕ: поддержаны только decoder-only архитектуры с привычной
    структурой блока (GPT-2, Llama/Mistral-семейство). Для других
    архитектур (например, с relative position encoding не как у Llama)
    нужно добавить свою ветку — это по конструкции не "подходит всем",
    как и у Petals (они тоже поддерживают ограниченный список архитектур).
    """
    model_type = getattr(config, "model_type", None)

    if model_type == "gpt2":
        from transformers.models.gpt2.modeling_gpt2 import GPT2Block
        return [GPT2Block(config, layer_idx=i) for i in range(num_blocks)]

    if model_type in ("llama", "mistral", "qwen2"):
        # Mistral/Qwen2 используют архитектурно совместимый с Llama блок
        # decoder-layer (RMSNorm + RoPE + SwiGLU) — поэтому можно
        # переиспользовать LlamaDecoderLayer как общий случай, но для
        # полной точности в проде лучше брать "родной" класс каждой модели.
        from transformers.models.llama.modeling_llama import LlamaDecoderLayer
        return [LlamaDecoderLayer(config, layer_idx=i) for i in range(num_blocks)]

    raise NotImplementedError(
        f"Архитектура '{model_type}' не поддержана. Добавь ветку в "
        f"_build_block_modules для этого model_type."
    )


def _load_shard_weights(blocks: list, state_dict: dict) -> None:
    """
    Распределяет веса из общего state_dict шарда (ключи вида
    'block_0.attn.c_attn.weight') по отдельным модулям блоков,
    снимая префикс 'block_{i}.' для каждого.
    """
    for local_idx, block in enumerate(blocks):
        prefix = f"block_{local_idx}."
        block_state = {
            key[len(prefix):]: value
            for key, value in state_dict.items()
            if key.startswith(prefix)
        }
        if not block_state:
            raise ValueError(
                f"Не найдено весов для блока {local_idx} (искали префикс '{prefix}') — "
                f"проверь, что shard был создан функцией load_and_split."
            )
        missing, unexpected = block.load_state_dict(block_state, strict=False)
        if missing or unexpected:
            # В проде стоит решить, фатально ли это (например, bias
            # отсутствует из-за quantization) — здесь только предупреждаем.
            import warnings
            warnings.warn(
                f"Блок {local_idx}: missing={missing}, unexpected={unexpected}"
            )


def block_runner_from_shard(shard: ModelShard, config):
    """
    Создаёт функцию block_runner(payload, start, end) -> bytes, которую
    ожидает transport/asyncio_transport.py и transport/grpc_server.py.
    Внутри — реальный forward pass через блоки этого шарда.

    УПРОЩЕНИЕ ПРОТИВ PETALS: без KV-кэша между последовательными
    запросами генерации — каждый вызов runner() независим и
    пересчитывает attention с нуля для всего переданного контекста.
    Это корректно, но медленнее при пошаговой генерации токен-за-токеном
    (Petals специально передаёт past_key_values между вызовами для
    ускорения — следующий шаг развития этого кода, не реализовано здесь).
    """
    import torch

    num_blocks = shard.block_end - shard.block_start
    blocks = _build_block_modules(config, num_blocks)

    buffer = io.BytesIO(shard.state_dict_bytes)
    state_dict = torch.load(buffer, map_location="cpu")
    _load_shard_weights(blocks, state_dict)

    for block in blocks:
        block.eval()

    model_type = getattr(config, "model_type", None)

    def runner(payload: bytes, block_start: int, block_end: int) -> bytes:
        hidden_states = torch.load(io.BytesIO(payload), map_location="cpu")
        batch_size, seq_len = hidden_states.shape[0], hidden_states.shape[1]

        # Причинная (causal) маска — каждый токен видит только предыдущие.
        # Упрощение: без padding-маски, предполагается один непрерывный
        # батч без паддинга. Для реального продакшена с переменной
        # длиной последовательностей маску нужно передавать из payload,
        # а не пересобирать заново на каждом узле.
        causal_mask = torch.triu(
            torch.full((seq_len, seq_len), float("-inf")), diagonal=1
        )

        with torch.no_grad():
            for local_idx in range(block_end - block_start):
                block = blocks[local_idx]
                if model_type == "gpt2":
                    hidden_states = block(hidden_states, attention_mask=causal_mask)[0]
                else:  # llama/mistral/qwen2
                    position_ids = torch.arange(seq_len).unsqueeze(0).expand(batch_size, -1)
                    hidden_states = block(
                        hidden_states,
                        attention_mask=causal_mask,
                        position_ids=position_ids,
                    )[0]

        out_buffer = io.BytesIO()
        torch.save(hidden_states, out_buffer)
        return out_buffer.getvalue()

    return runner
