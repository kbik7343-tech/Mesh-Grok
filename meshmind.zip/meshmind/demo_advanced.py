"""
demo_advanced.py — связывает четыре "продвинутых" модуля в одном
сценарии, поверх реальной сети (как и demo_end_to_end.py для базовых
модулей):

  1. GOSSIP — 3 узла находят друг друга без центрального координатора
  2. VERIFICATION — узлы считают блоки с commit-reveal, координатор
     выборочно перепроверяет честность
  3. SPECULATIVE DECODING — локальный черновик + один сетевой вызов
     на верификацию пачки токенов вместо последовательных вызовов
  4. FEDERATED — узлы присылают обновления весов, координатор
     усредняет их с защитой от атаки отравления

Запуск: python3 demo_advanced.py
"""

from __future__ import annotations

import asyncio
import logging

from meshmind.hybrid.federated import ClientUpdate, apply_update, federated_average, filter_outlier_updates
from meshmind.hybrid.speculative import speculative_generate
from meshmind.transport.gossip import GossipNode
from meshmind.verification.commit_verify import SpotCheckVerifier, commit

logging.basicConfig(level=logging.WARNING)


async def demo_gossip() -> None:
    print("\n" + "=" * 60)
    print("1. GOSSIP — самоорганизация топологии (реальная TCP-сеть)")
    print("=" * 60)

    nodeA = GossipNode(node_id="nodeA", fanout=2)
    nodeB = GossipNode(node_id="nodeB", fanout=2)
    nodeC = GossipNode(node_id="nodeC", fanout=2)

    portA, portB, portC = await nodeA.start(), await nodeB.start(), await nodeC.start()
    try:
        # Только C изначально знает про A и B — имитация "посредника" при старте сети
        await nodeC.bootstrap("127.0.0.1", portA)
        await nodeC.bootstrap("127.0.0.1", portB)
        print(f"До gossip: nodeA знает {list(nodeA.known_peers.keys())}")

        await nodeA.gossip_round()
        print(f"После 1 раунда gossip: nodeA знает {list(nodeA.known_peers.keys())}")
        print("-> nodeA узнал про nodeB ТРАНЗИТИВНО через nodeC, без прямого подключения")
    finally:
        await nodeA.stop()
        await nodeB.stop()
        await nodeC.stop()


def demo_verification() -> None:
    print("\n" + "=" * 60)
    print("2. VERIFICATION — commit-reveal + выборочные перепроверки")
    print("=" * 60)

    verifier = SpotCheckVerifier(check_probability=0.3)

    def honest_block_compute(payload: bytes) -> bytes:
        return payload + b"|processed_honestly"

    def cheating_block_compute(payload: bytes) -> bytes:
        return b"made_up_lazy_answer"  # узел не считал, просто выдумал

    for node_id, compute_fn in [("honestNode", honest_block_compute), ("lazyNode", cheating_block_compute)]:
        payload = b"request_data"
        nonce = f"{node_id}_nonce".encode()
        output = compute_fn(payload)

        verifier.record_commitment(f"req_{node_id}", node_id, payload, output, nonce)

        # Координатор пересчитывает сам (доверенно) и сверяет
        trusted_result = honest_block_compute(payload)  # "правильный" ответ
        honest = verifier.spot_check(f"req_{node_id}", trusted_recomputation=trusted_result)

        print(f"{node_id}: честен={honest}, пойман на обмане {verifier.cheating_count(node_id)} раз")

    print(f"lazyNode помечен для исключения из сети: {verifier.is_flagged('lazyNode', threshold=1)}")


def demo_speculative() -> None:
    print("\n" + "=" * 60)
    print("3. SPECULATIVE DECODING — черновик + 1 сетевой вызов вместо N")
    print("=" * 60)

    correct_sequence = ["Привет", ",", "как", "дела", "?"]

    def local_draft_model(context: list[str], k: int) -> list[str]:
        # "Локальная модель" — знает правильную последовательность не хуже большой
        pos = len(context)
        return correct_sequence[pos:pos + k]

    def network_verify_call(context: list[str], draft: list[str]) -> list[bool]:
        # Единственный сетевой вызов к распределённой/облачной модели —
        # проверяет весь пакет черновика разом
        pos = len(context)
        return [
            pos + i < len(correct_sequence) and correct_sequence[pos + i] == tok
            for i, tok in enumerate(draft)
        ]

    result = speculative_generate([], local_draft_model, network_verify_call, num_speculative_tokens=5)
    print(f"Черновик локальной модели: {result.num_drafted} токенов")
    print(f"Принято без доп. сетевых вызовов: {result.accepted_tokens}")
    print(f"Сэкономлено сетевых round-trip'ов: {result.network_calls_saved} "
          f"(вместо {result.num_accepted} последовательных вызовов — всего 1)")


def demo_federated() -> None:
    print("\n" + "=" * 60)
    print("4. FEDERATED — усреднение обновлений + защита от атаки")
    print("=" * 60)

    global_weights = [1.0, 1.0, 1.0]

    updates = [
        ClientUpdate("userDeviceA", [0.05, 0.02, -0.01], num_local_samples=500),
        ClientUpdate("userDeviceB", [0.03, -0.01, 0.04], num_local_samples=300),
        ClientUpdate("maliciousNode", [50.0, -50.0, 50.0], num_local_samples=1),  # атака
    ]

    kept, rejected = filter_outlier_updates(updates, max_delta_norm=1.0)
    print(f"Узлов прислало обновления: {len(updates)}")
    print(f"Отклонено как аномальные: {rejected}")

    avg_delta = federated_average(kept)
    new_weights = apply_update(global_weights, avg_delta)

    print(f"Глобальные веса до раунда:  {[round(w, 3) for w in global_weights]}")
    print(f"Глобальные веса после:      {[round(w, 3) for w in new_weights]}")
    print("-> Веса сдвинулись лишь немного от честных узлов, атака не прошла")


async def main() -> None:
    print("MESHMIND — ДЕМО ПРОДВИНУТЫХ МОДУЛЕЙ")
    await demo_gossip()
    demo_verification()
    demo_speculative()
    demo_federated()
    print("\n" + "=" * 60)
    print("ВСЁ ВМЕСТЕ: сеть сама нашла себя (gossip), не доверяет узлам")
    print("вслепую (verification), экономит сетевые вызовы (speculative),")
    print("и дообучается без сбора сырых данных, устойчиво к атакам (federated).")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
