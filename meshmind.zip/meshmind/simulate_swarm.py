"""
simulate_swarm.py — нагрузочный тест router.py на сотнях узлов.

Генерирует случайную сеть узлов с реалистичным разбросом задержки и
надёжности (часть узлов "плохие" — высокий пинг или частые сбои),
прогоняет через неё много запросов и меряет: сколько маршрутов
построилось успешно, как балансировалась нагрузка, и как часто
роутер отдавал предпочтение хорошим узлам перед плохими.

Запуск: python3 simulate_swarm.py
"""

from __future__ import annotations

import random
import statistics
import time

from meshmind.router import RoutingTable

random.seed(42)  # воспроизводимость результатов между запусками


def build_synthetic_swarm(
    router: RoutingTable,
    num_nodes: int = 300,
    num_blocks: int = 40,
    replication: int = 3,
    bad_node_fraction: float = 0.15,
) -> dict[str, dict]:
    """
    Создаёт num_nodes узлов, каждый — владелец нескольких случайных блоков
    (replication = сколько копий каждого блока в сети). Доля bad_node_fraction
    узлов — "проблемные" (высокая задержка/низкая надёжность), остальные —
    нормальные, чтобы проверить, действительно ли роутер их избегает.
    """
    node_profiles: dict[str, dict] = {}
    node_ids = [f"node-{i:04d}" for i in range(num_nodes)]

    for node_id in node_ids:
        is_bad = random.random() < bad_node_fraction
        if is_bad:
            profile = {
                "base_latency": random.uniform(400, 1200),
                "fail_prob": random.uniform(0.2, 0.6),
            }
        else:
            profile = {
                "base_latency": random.uniform(20, 150),
                "fail_prob": random.uniform(0.0, 0.05),
            }
        node_profiles[node_id] = profile

    # Каждый блок реплицирован на нескольких случайных узлах
    for block_id in range(num_blocks):
        owners = random.sample(node_ids, k=min(replication, num_nodes))
        for owner in owners:
            router.register_block_owner(block_id, owner)

    return node_profiles


def simulate_request(
    router: RoutingTable,
    profiles: dict[str, dict],
    num_blocks: int,
) -> tuple[bool, float]:
    """Строит маршрут, имитирует прохождение запроса через все узлы."""
    try:
        route = router.build_route(num_blocks)
    except RuntimeError:
        return False, 0.0

    total_latency = 0.0
    request_ok = True
    for node_id in route:
        profile = profiles[node_id]
        latency = random.gauss(profile["base_latency"], profile["base_latency"] * 0.2)
        latency = max(5.0, latency)
        failed = random.random() < profile["fail_prob"]

        router.report_result(node_id, ok=not failed, latency_ms=latency)
        total_latency += latency
        if failed:
            request_ok = False
            break  # реальный пайплайн прервётся на первом отказавшем узле

    router.release_route(route)
    return request_ok, total_latency


def run_simulation(
    num_nodes: int = 300,
    num_blocks: int = 40,
    num_requests: int = 2000,
    warmup_requests: int = 300,
) -> None:
    router = RoutingTable()
    profiles = build_synthetic_swarm(router, num_nodes=num_nodes, num_blocks=num_blocks)
    bad_nodes = {n for n, p in profiles.items() if p["fail_prob"] > 0.1}

    print(f"Сеть: {num_nodes} узлов ({len(bad_nodes)} проблемных), {num_blocks} блоков модели")
    print(f"Прогреваю роутер на {warmup_requests} запросах, чтобы собрать статистику узлов...")

    for _ in range(warmup_requests):
        simulate_request(router, profiles, num_blocks)

    print(f"Измеряю на {num_requests} запросах после прогрева...\n")

    successes = 0
    latencies: list[float] = []
    bad_node_usage = 0
    total_node_uses = 0
    start = time.time()

    for _ in range(num_requests):
        ok, latency = simulate_request(router, profiles, num_blocks)
        if ok:
            successes += 1
            latencies.append(latency)

    # Считаем, как часто роутер выбирал "плохие" узлы уже ПОСЛЕ прогрева —
    # то есть насколько хорошо он научился их избегать.
    for _ in range(200):
        try:
            route = router.build_route(num_blocks)
        except RuntimeError:
            continue
        router.release_route(route)
        for node_id in route:
            total_node_uses += 1
            if node_id in bad_nodes:
                bad_node_usage += 1

    elapsed = time.time() - start

    print("=== Результаты ===")
    print(f"Успешных запросов: {successes}/{num_requests} ({successes/num_requests:.1%})")
    if latencies:
        print(f"Средняя задержка успешного запроса: {statistics.mean(latencies):.0f} мс")
        print(f"Медиана: {statistics.median(latencies):.0f} мс")
        print(f"p95: {sorted(latencies)[int(len(latencies)*0.95)]:.0f} мс")
    print(f"Доля использования 'плохих' узлов после обучения роутера: "
          f"{bad_node_usage/total_node_uses:.1%} "
          f"(при случайном выборе было бы ~{len(bad_nodes)/num_nodes:.1%})")
    print(f"Время симуляции: {elapsed:.2f} с ({num_requests/elapsed:.0f} запросов/сек)")

    print("\nТоп-5 узлов по репутации роутера:")
    for line in router.snapshot()[:5]:
        print(" ", line)
    print("\nХуже всего оцененные 5 узлов (роутер их почти не использует):")
    for line in router.snapshot()[-5:]:
        print(" ", line)


if __name__ == "__main__":
    run_simulation()
