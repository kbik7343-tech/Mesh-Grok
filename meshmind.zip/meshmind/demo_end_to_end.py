"""
demo_end_to_end.py — связывает ВСЕ модули проекта в одном рабочем
сценарии: несколько узлов поднимаются как настоящие TCP-серверы,
запросы реально идут по сети, роутер учится избегать плохие узлы,
система стимулов начисляет очки, приватность шифрует трафик, а
гибридный оркестратор решает, нужна ли вообще сеть для этого
запроса или хватит локальной модели.

Это не juнит-тест (те уже есть в tests/), а наглядная демонстрация
того, что куски, протестированные по отдельности, работают и вместе.

Запуск: python3 demo_end_to_end.py
"""

from __future__ import annotations

import asyncio
import logging

from meshmind.hybrid.complexity import RouteTarget, decide_route
from meshmind.incentives import IncentiveLedger
from meshmind.privacy import HopEncryption
from meshmind.router import RoutingTable
from meshmind.transport.asyncio_transport import MeshClient, NodeServer

logging.basicConfig(level=logging.WARNING)


# --- "Облачная" распределённая сеть из 3 узлов с шифрованием каждого прыжка ---

def make_block_runner(node_name: str, hop_encryption: HopEncryption):
    """
    Узел расшифровывает входящие активации, 'обрабатывает' их (здесь —
    условно, добавлением метки узла) и шифрует результат для следующего
    прыжка — тот же сценарий, что в privacy.py, но внутри реальной
    сетевой цепочки, а не в изоляции.
    """

    def runner(payload: bytes, block_start: int, block_end: int) -> bytes:
        try:
            plain = hop_encryption.decrypt(payload)
        except Exception:
            plain = payload  # первый узел в цепочке получает нешифрованный вход
        processed = plain + f"|{node_name}".encode()
        return hop_encryption.encrypt(processed)

    return runner


async def run_distributed_request(prompt: str, router: RoutingTable, ledger: IncentiveLedger,
                                   addresses: dict, hop_key: bytes) -> str:
    """Прогоняет один запрос через реальную сеть узлов, с шифрованием и учётом вклада."""
    hop_encryption = HopEncryption(session_key=hop_key)
    client = MeshClient(addresses, router)

    encrypted_input = hop_encryption.encrypt(prompt.encode())
    result_bytes = await client.run_inference(encrypted_input, num_blocks=3)
    result = hop_encryption.decrypt(result_bytes).decode()

    # Начисляем очки всем узлам маршрута — используем снимок роутера,
    # чтобы узнать, кто реально обработал запрос (см. router.snapshot())
    for node_id in addresses:
        if router._health[node_id].success_rate > 0:  # участвовал и не упал
            ledger.record_success(node_id)

    return result


async def main() -> None:
    print("=" * 60)
    print("MESHMIND — END-TO-END ДЕМО")
    print("=" * 60)

    # --- 1. Поднимаем реальную распределённую сеть из 3 узлов ---
    hop_key = HopEncryption().key  # общий сессионный ключ для демо (в проде — handshake per-hop)
    router = RoutingTable()
    ledger = IncentiveLedger(storage_path=None)

    servers = []
    addresses = {}
    for i, name in enumerate(["nodeA", "nodeB", "nodeC"]):
        hop_enc = HopEncryption(session_key=hop_key)
        server = NodeServer(node_id=name, block_runner=make_block_runner(name, hop_enc))
        port = await server.start()
        servers.append(server)
        addresses[name] = ("127.0.0.1", port)
        router.register_block_owner(i, name)

    print(f"\nПоднято {len(servers)} узлов сети: {list(addresses.keys())}")

    try:
        # --- 2. Гибридная маршрутизация: часть запросов вообще не идёт в сеть ---
        test_prompts = [
            "привет, как дела?",                              # простой -> локально, сеть не нужна
            "напиши def foo(): для сортировки списка",        # сложный -> распределённая сеть
            "сколько будет 2 плюс 2?",                         # простой -> локально
            "во-первых проверь погоду, затем купи молоко",     # многошаговый -> сеть
        ]

        print("\n--- Гибридная маршрутизация запросов ---")
        network_calls = 0
        local_calls = 0

        for prompt in test_prompts:
            decision = decide_route(prompt, is_online=True)
            print(f"\n[{decision.target.value.upper()}] «{prompt}»")
            print(f"  причина: {decision.reason}")

            if decision.target == RouteTarget.CLOUD:
                result = await run_distributed_request(prompt, router, ledger, addresses, hop_key)
                print(f"  результат из сети (расшифрован): {result!r}")
                network_calls += 1
            else:
                print(f"  обработано локально, сеть не задействована")
                local_calls += 1

        # --- 3. Итоговая статистика по всем подсистемам ---
        print("\n" + "=" * 60)
        print("ИТОГИ")
        print("=" * 60)
        print(f"Запросов обработано локально: {local_calls}")
        print(f"Запросов ушло в распределённую сеть: {network_calls}")

        print("\nСостояние роутера (реальные сетевые метрики):")
        for line in router.snapshot():
            print(" ", line)

        print("\nРейтинг узлов по вкладу (incentives.py):")
        for line in ledger.leaderboard():
            print(" ", line)

        print(f"\nЭкономия сети от гибридного подхода: "
              f"{local_calls}/{len(test_prompts)} запросов не потребовали "
              f"ни одного сетевого вызова, ни шифрования, ни участия узлов.")

    finally:
        for server in servers:
            await server.stop()


if __name__ == "__main__":
    asyncio.run(main())
